"""
ParsLinux Kurulum Sihirbazı - Yapılandırma ve Çevre Tanımları
Linux ve GNOME/Libadwaita standartlarına uygun yol ve meta veri yönetimi.
"""

import os
import sys
import gettext

APP_ID = "org.parslinux.setup"
APP_NAME = "ParsLinux Kurulum Sihirbazı"
VERSION = "1.0.0"
RELEASE_CODENAME = "Pars"
GETTEXT_PACKAGE = "pars-setup"

# Çalışma dizini tespiti: Kaynak koddan mı yoksa /usr (/usr/local) sisteminden mi çalışıyor?
SRC_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(SRC_DIR)

# Sistemde yüklü ise yollar /usr/share/... olur, kaynak dizinindeyse yerel data/ kullanılır
if os.path.exists(os.path.join(PROJECT_ROOT, "data")):
    DATA_DIR = os.path.join(PROJECT_ROOT, "data")
    LOCALE_DIR = os.path.join(PROJECT_ROOT, "po", "mo")
else:
    DATA_DIR = "/usr/share/pars-setup"
    LOCALE_DIR = "/usr/share/locale"

# Uluslararasılaştırma (i18n / gettext)
try:
    locale_dir = LOCALE_DIR if os.path.exists(LOCALE_DIR) else None
    t = gettext.translation(GETTEXT_PACKAGE, localedir=locale_dir, fallback=True)
    _ = t.gettext
except Exception:
    _ = lambda s: s

# Simülasyon / Gerçek Kurulum Modu
IS_SIMULATION = os.environ.get("PARS_REAL_INSTALL", "0") != "1"
