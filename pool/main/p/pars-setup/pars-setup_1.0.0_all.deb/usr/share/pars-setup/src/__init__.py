"""
ParsLinux Setup Application Package
"""
