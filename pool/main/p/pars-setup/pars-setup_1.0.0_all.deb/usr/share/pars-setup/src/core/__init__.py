"""
ParsLinux Setup Core Package
"""
from .hardware import get_full_hardware_summary, is_uefi, get_ram_info, get_battery_info, get_network_info
from .disks import get_block_devices, calculate_alongside_plan, calculate_erase_plan
from .locales import SUPPORTED_LANGUAGES, KEYBOARD_LAYOUTS, TIMEZONES, apply_live_keyboard
from .users import sanitize_username, sanitize_hostname, evaluate_password, validate_user_config
from .installer import InstallerEngine
