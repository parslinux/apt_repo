"""
ParsLinux / Linux OS Kurulum Sihirbazı - Donanım Tespit Modülü
psutil, platform ve /proc, /sys üzerinden yüksek hassasiyetli donanım tespiti yapar.
"""

import os
import subprocess
import socket
import json
import shutil
import platform

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False


def is_uefi() -> bool:
    """Sistemin UEFI modunda mı yoksa Legacy BIOS modunda mı çalıştığını tespit eder."""
    return os.path.exists("/sys/firmware/efi")


def get_ram_info() -> dict:
    """Toplam ve kullanılabilir RAM bilgisini tespit eder."""
    if HAS_PSUTIL:
        try:
            vm = psutil.virtual_memory()
            total_gb = round(vm.total / (1024 ** 3), 1)
            avail_gb = round(vm.available / (1024 ** 3), 1)
            return {
                "total_gb": total_gb,
                "available_gb": avail_gb,
                "text": f"{total_gb} GB RAM ({avail_gb} GB Boş)",
                "sufficient": total_gb >= 2.0
            }
        except Exception:
            pass

    # Yedek: /proc/meminfo okuma
    total_kb = 0
    avail_kb = 0
    try:
        with open("/proc/meminfo", "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    total_kb = int(line.split()[1])
                elif line.startswith("MemAvailable:"):
                    avail_kb = int(line.split()[1])
        total_gb = round(total_kb / (1024 * 1024), 1)
        avail_gb = round(avail_kb / (1024 * 1024), 1)
        return {
            "total_gb": total_gb,
            "available_gb": avail_gb,
            "text": f"{total_gb} GB RAM ({avail_gb} GB Boş)",
            "sufficient": total_gb >= 2.0
        }
    except Exception:
        return {"total_gb": 4.0, "available_gb": 2.0, "text": "4.0 GB (Tahmini)", "sufficient": True}


def get_battery_info() -> dict:
    """Pil ve adaptör şarj durumunu tespit eder."""
    if HAS_PSUTIL:
        try:
            batt = psutil.sensors_battery()
            if batt:
                pct = int(round(batt.percent))
                charging = bool(batt.power_plugged)
                status_text = f"Şarj Ediliyor (%{pct})" if charging else f"Pilde (%{pct})"
                return {
                    "has_battery": True,
                    "percentage": pct,
                    "charging": charging,
                    "status": status_text,
                    "sufficient": charging or pct >= 20
                }
        except Exception:
            pass

    # Yedek: /sys/class/power_supply
    power_dir = "/sys/class/power_supply"
    if not os.path.exists(power_dir):
        return {"has_battery": False, "status": "Masaüstü (Şebeke Gücü)", "percentage": 100, "charging": True, "sufficient": True}

    try:
        supplies = os.listdir(power_dir)
        battery_found = False
        percentage = 100
        charging = True

        for sup in supplies:
            sup_path = os.path.join(power_dir, sup)
            type_file = os.path.join(sup_path, "type")
            if os.path.exists(type_file):
                with open(type_file, "r") as f:
                    sup_type = f.read().strip()
                if sup_type == "Battery":
                    battery_found = True
                    cap_file = os.path.join(sup_path, "capacity")
                    stat_file = os.path.join(sup_path, "status")
                    if os.path.exists(cap_file):
                        with open(cap_file, "r") as cf:
                            percentage = int(cf.read().strip())
                    if os.path.exists(stat_file):
                        with open(stat_file, "r") as sf:
                            status_val = sf.read().strip()
                            charging = status_val in ["Charging", "Full"]
                    break

        if battery_found:
            status_text = f"Şarj Ediliyor (%{percentage})" if charging else f"Pilde (%{percentage})"
            return {
                "has_battery": True,
                "percentage": percentage,
                "charging": charging,
                "status": status_text,
                "sufficient": charging or percentage >= 20
            }
        else:
            return {
                "has_battery": False,
                "status": "Masaüstü / Şebekeye Bağlı",
                "percentage": 100,
                "charging": True,
                "sufficient": True
            }
    except Exception:
        return {"has_battery": False, "status": "Şebeke Gücü Aktif", "percentage": 100, "charging": True, "sufficient": True}


def get_network_info() -> dict:
    """İnternet bağlantısını hızlıca test eder."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1.0)
        sock.connect(("1.1.1.1", 53))
        sock.close()
        return {"online": True, "status": "Çevrimiçi (İnternet Bağlantısı Aktif)", "type": "Aktif Ağ"}
    except Exception:
        return {"online": False, "status": "Çevrimdışı (İnternet Yok - Çevrimdışı Kurulabilir)", "type": "Yok"}


def get_cpu_info() -> dict:
    """İşlemci modelini, çekirdek sayısını ve mimariyi alır."""
    arch = platform.machine()
    logical_cores = os.cpu_count() or 4
    physical_cores = logical_cores
    if HAS_PSUTIL:
        try:
            logical_cores = psutil.cpu_count(logical=True) or logical_cores
            physical_cores = psutil.cpu_count(logical=False) or physical_cores
        except Exception:
            pass

    model_name = "x86_64 Çok Çekirdekli İşlemci"
    try:
        with open("/proc/cpuinfo", "r", encoding="utf-8") as f:
            for line in f:
                if "model name" in line:
                    model_name = line.split(":")[1].strip()
                    break
    except Exception:
        pass

    return {
        "model": model_name,
        "logical_cores": logical_cores,
        "physical_cores": physical_cores,
        "arch": arch,
        "summary": f"{model_name} ({logical_cores} Çekirdek, {arch})"
    }


def get_full_hardware_summary() -> dict:
    """Tüm donanım durumu özetini döndürür."""
    uefi = is_uefi()
    ram = get_ram_info()
    bat = get_battery_info()
    net = get_network_info()
    cpu = get_cpu_info()

    return {
        "uefi": uefi,
        "boot_mode": "UEFI / GPT" if uefi else "Legacy BIOS / MBR",
        "cpu": cpu["summary"],
        "cpu_details": cpu,
        "ram": ram,
        "battery": bat,
        "network": net,
        "all_requirements_met": ram["sufficient"] and bat["sufficient"]
    }


if __name__ == "__main__":
    print(json.dumps(get_full_hardware_summary(), indent=2, ensure_ascii=False))
