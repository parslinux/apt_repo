"""
ParsLinux / Linux OS Kurulum Sihirbazı - Kurulum Motoru (Installer Engine)
Gerçek donanıma kurulum (root yetkisiyle) veya güvenli simülasyon (varsayılan) işlemlerini yürütür.
"""

import time
import threading
import queue
import subprocess
import os
import shutil
import glob


class InstallerEngine:
    def __init__(self, is_simulation: bool = True):
        self.is_simulation = is_simulation
        self.progress = 0
        self.current_stage = "Hazırlanıyor..."
        self.is_running = False
        self.is_finished = False
        self.has_error = False
        self.error_message = ""
        self.logs_queue = queue.Queue()
        self.all_logs = []
        self._thread = None
        self._active_mounts = []

    def log(self, text: str):
        """Uçbirim günlüğüne yeni bir satır ekler."""
        formatted = f">> {text}"
        self.all_logs.append(formatted)
        self.logs_queue.put(formatted)

    def _exec(self, cmd: list, input_str: str = None, check: bool = True) -> str:
        """
        Komutu çalıştırır veya simüle eder.
        Simülasyon modunda komutu günlüğe yazar ve güvenle geçer.
        Gerçek modda alt süreç oluşturur ve çıktıları canlı loglar.
        """
        cmd_str = " ".join(cmd)
        self.log(f"$ {cmd_str}")

        if self.is_simulation:
            time.sleep(0.15)
            return ""

        try:
            stdin_data = input_str.encode('utf-8') if input_str is not None else None
            proc = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE if input_str is not None else None,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True
            )

            stdout_lines = []
            if stdin_data:
                stdout_data, _ = proc.communicate(input=input_str)
                for line in stdout_data.splitlines():
                    if line.strip():
                        self.log(line)
                        stdout_lines.append(line)
            else:
                for line in proc.stdout:
                    line_str = line.strip()
                    if line_str:
                        self.log(line_str)
                        stdout_lines.append(line_str)
                proc.wait()

            if check and proc.returncode != 0:
                raise RuntimeError(f"Komut hata kodu {proc.returncode} ile sonlandı: {cmd_str}")

            return "\n".join(stdout_lines)
        except Exception as e:
            self.log(f"UYARI: Komut hatası: {e}")
            if check:
                raise
            return ""

    def start_installation(self, config: dict):
        """Kurulum sürecini arka plan iş parçacığında başlatır."""
        if self.is_running:
            return False
        
        self.is_running = True
        self.is_finished = False
        self.has_error = False
        self.progress = 0
        self.all_logs.clear()
        
        self._thread = threading.Thread(target=self._run_install_pipeline, args=(config,), daemon=True)
        self._thread.start()
        return True

    def _find_squashfs_image(self) -> str:
        """Canlı ISO veya sistem SquashFS imaj dosyasının yolunu bulur."""
        candidates = [
            "/run/live/medium/live/filesystem.squashfs",
            "/run/live/medium/casper/filesystem.squashfs",
            "/cdrom/casper/filesystem.squashfs",
            "/cdrom/live/filesystem.squashfs",
            "/lib/live/mount/medium/live/filesystem.squashfs",
            "/run/archiso/bootmnt/parslinux/x86_64/airootfs.sfs"
        ]
        for path in candidates:
            if os.path.exists(path):
                return path

        # Glob ile /run/live/ veya /cdrom altındaki tüm .squashfs dosyalarını dene
        for pattern in ["/run/live/**/*.squashfs", "/cdrom/**/*.squashfs", "/live/**/*.squashfs"]:
            matches = glob.glob(pattern, recursive=True)
            if matches:
                return matches[0]

        return ""

    def _get_partition_path(self, disk_path: str, part_num: int) -> str:
        """NVMe veya SATA/SCSI disk yapısına göre bölüm yolunu hesaplar (/dev/nvme0n1p1 vs /dev/sda1)."""
        if disk_path[-1].isdigit():
            return f"{disk_path}p{part_num}"
        return f"{disk_path}{part_num}"

    def _cleanup_mounts(self):
        """Hata durumunda veya kurulum bitişinde /target bağlamalarını güvenle temizler."""
        if self.is_simulation:
            return

        self.log("Geçici bağlama noktaları kontrol ediliyor...")
        try:
            subprocess.run(["umount", "-R", "/target"], capture_output=True)
            subprocess.run(["cryptsetup", "close", "pars-root"], capture_output=True)
        except Exception:
            pass

    def _run_install_pipeline(self, config: dict):
        try:
            target_disk = config.get("target_disk", "/dev/nvme0n1")
            mode = config.get("install_type", "alongside")
            username = config.get("username", "pars")
            fullname = config.get("fullname", "Pars Kullanıcısı")
            hostname = config.get("hostname", "parslinux-pc")
            password = config.get("password", "")
            autologin = config.get("autologin", False)
            rootsame = config.get("rootsame", True)
            timezone = config.get("timezone", "Europe/Istanbul")
            locale = config.get("locale", "tr_TR.UTF-8")
            third_party = config.get("third_party_drivers", True)
            fs_type = config.get("filesystem", "ext4").lower()
            swap_type = config.get("swap_type", "zram")
            luks_enabled = config.get("luks_enabled", False)
            luks_password = config.get("luks_password", "")
            has_windows = config.get("has_windows", False)
            ntp_enabled = config.get("ntp", True)
            kb_layout = config.get("keyboard_layout", "tr")
            is_oem = config.get("is_oem", False)
            linux_gb = config.get("linux_gb", 150)

            mode_str = "SİMÜLASYON (GÜVENLİ)" if self.is_simulation else "GERÇEK KURULUM (DİSKE YAZILIYOR)"
            self.log(f"=== ParsLinux Kurulum Motoru [{mode_str}] ===")
            self.log(f"Hedef Disk: {target_disk} | Kurulum Modu: {mode}")
            self.log(f"Dosya Sistemi: {fs_type.upper()} | Swap: {swap_type} | LUKS2: {luks_enabled}")
            self.log(f"Kullanıcı: {username}@{hostname} | Saat Dilimi: {timezone} | Klavye: {kb_layout}")
            time.sleep(0.5)

            # =========================================================================
            # AŞAMA 1: DİSK BÖLÜMLEME VE BİÇİMLENDİRME (0% - 25%)
            # =========================================================================
            self.current_stage = "Disk bölümleri yapılandırılıyor..."
            self._update_progress(5)

            esp_partition = self._get_partition_path(target_disk, 1)
            root_partition = self._get_partition_path(target_disk, 2)
            active_root_device = root_partition

            if mode == "erase":
                self.log(f"DİSK SİLİNİYOR: {target_disk} üzerindeki bölümleme tablosu sıfırlanıyor...")
                self._exec(["wipefs", "-a", "-f", target_disk], check=False)
                self._exec(["parted", "-s", target_disk, "mklabel", "gpt"])
                time.sleep(0.4)

                self.log(f"EFI Sistem Bölümü (ESP) oluşturuluyor (512 MB, FAT32)...")
                self._exec(["parted", "-s", target_disk, "mkpart", "EFI", "fat32", "1MiB", "513MiB"])
                self._exec(["parted", "-s", target_disk, "set", "1", "esp", "on"])
                time.sleep(0.3)

                self.log(f"Kök dosya sistemi bölümü oluşturuluyor: {root_partition} (Kalan tüm alan)...")
                self._exec(["parted", "-s", target_disk, "mkpart", "ParsLinux", fs_type, "513MiB", "100%"])
                time.sleep(0.4)
            elif mode == "alongside":
                self.log(f"Dual-Boot: {target_disk} diski üzerinde {linux_gb} GB ayrılıyor...")
                # Mevcut bölümleri koru, serbest alana yeni bölüm aç
                self._exec(["parted", "-s", target_disk, "print"], check=False)
                time.sleep(0.5)
            else:
                self.log(f"Manuel mod: {target_disk} üzerindeki mevcut bölümler hedefleniyor.")

            self._update_progress(12)

            # LUKS2 Şifreleme
            if luks_enabled:
                self.log(f"LUKS2 Tam Disk Şifreleme uygulanıyor: {root_partition}")
                self.log(">> Algoritma: aes-xts-plain64, 512-bit anahtar, Argon2id KDF")
                self._exec(
                    ["cryptsetup", "luksFormat", "--type", "luks2", "--cipher", "aes-xts-plain64",
                     "--key-size", "512", "--pbkdf", "argon2id", root_partition],
                    input_str=f"{luks_password}\n" if luks_password else "parslinux\n"
                )
                self._exec(
                    ["cryptsetup", "open", root_partition, "pars-root"],
                    input_str=f"{luks_password}\n" if luks_password else "parslinux\n"
                )
                active_root_device = "/dev/mapper/pars-root"
                self.log(f"Şifreli konteyner açıldı: {active_root_device}")

            self._update_progress(16)

            # Dosya Sistemlerini Biçimlendir
            self.log(f"EFI Bölümü FAT32 olarak biçimlendiriliyor: {esp_partition}...")
            self._exec(["mkfs.vfat", "-F32", "-n", "PARS_EFI", esp_partition], check=False)

            if fs_type == "btrfs":
                self.log(f"Btrfs Modern Dosya Sistemi Biçimlendiriliyor (mkfs.btrfs -f -L 'PARSLINUX' {active_root_device})...")
                self._exec(["mkfs.btrfs", "-f", "-L", "PARSLINUX", active_root_device])
                
                # Hedefi bağla ve alt hacimleri (subvolumes) oluştur
                self._exec(["mkdir", "-p", "/target"])
                self._exec(["mount", active_root_device, "/target"])
                self.log("Btrfs Alt Hacimleri (Subvolumes) oluşturuluyor (@, @home, @snapshots)...")
                self._exec(["btrfs", "subvolume", "create", "/target/@"])
                self._exec(["btrfs", "subvolume", "create", "/target/@home"])
                self._exec(["btrfs", "subvolume", "create", "/target/@snapshots"])
                self._exec(["umount", "/target"])

                # Kök (@) ve alt hacimleri bağla
                self.log("Btrfs alt hacimleri montaj hiyerarşisine bağlanıyor...")
                self._exec(["mount", "-o", "noatime,compress=zstd:1,space_cache=v2,subvol=@", active_root_device, "/target"])
                self._exec(["mkdir", "-p", "/target/home", "/target/.snapshots"])
                self._exec(["mount", "-o", "noatime,compress=zstd:1,space_cache=v2,subvol=@home", active_root_device, "/target/home"])
                self._exec(["mount", "-o", "noatime,compress=zstd:1,space_cache=v2,subvol=@snapshots", active_root_device, "/target/.snapshots"])
            else:
                self.log(f"Ext4 Dosya Sistemi Biçimlendiriliyor (mkfs.ext4 -F -L 'PARSLINUX' {active_root_device})...")
                self._exec(["mkfs.ext4", "-F", "-L", "PARSLINUX", active_root_device])
                self._exec(["mkdir", "-p", "/target"])
                self._exec(["mount", active_root_device, "/target"])

            # EFI Bağlama
            self._exec(["mkdir", "-p", "/target/boot/efi"])
            self._exec(["mount", esp_partition, "/target/boot/efi"], check=False)

            # Swapfile (Eğer takas dosyası seçildiyse)
            if swap_type == "file":
                self.log("4 GB Takas Dosyası (swapfile) tahsis ediliyor...")
                self._exec(["fallocate", "-l", "4G", "/target/swapfile"], check=False)
                self._exec(["chmod", "600", "/target/swapfile"], check=False)
                self._exec(["mkswap", "/target/swapfile"], check=False)

            self._update_progress(25)

            # =========================================================================
            # AŞAMA 2: SİSTEM DOSYALARI KOPYALANIYOR (25% - 58%)
            # =========================================================================
            self.current_stage = "Sistem dosyaları diske kopyalanıyor..."
            squashfs_path = self._find_squashfs_image()

            if squashfs_path:
                self.log(f"Canlı sistem imajı bulundu: {squashfs_path}")
                self.log("SquashFS arşiv içeriği /target dizinine açılıyor (unsquashfs -f -d /target)...")
                self._exec(["unsquashfs", "-f", "-d", "/target", squashfs_path])
            else:
                self.log("Canlı ISO SquashFS imajı algılanamadı, yerel dosya hiyerarşisi senkronize ediliyor...")
                if self.is_simulation:
                    sim_steps = [
                        ("Temel GNU/Linux kök dizini kopyalanıyor...", 32),
                        ("Çekirdek paketleri (linux-image-generic) ayıklanıyor...", 40),
                        ("Masaüstü ortamı ve temel kütüphaneler yerleştiriliyor...", 48),
                        ("Kullanıcı alanı uygulamaları ve simgeler kopyalanıyor...", 58)
                    ]
                    for msg, p in sim_steps:
                        time.sleep(0.6)
                        self.log(msg)
                        self._update_progress(p)
                else:
                    rsync_cmd = [
                        "rsync", "-aHAX", "--delete",
                        "--exclude=/target", "--exclude=/proc", "--exclude=/sys",
                        "--exclude=/dev", "--exclude=/run", "--exclude=/mnt",
                        "--exclude=/media", "--exclude=/tmp",
                        "/", "/target"
                    ]
                    self._exec(rsync_cmd, check=False)

            self._update_progress(58)

            # =========================================================================
            # AŞAMA 3: SANAL DOSYA SİSTEMLERİ VE CHROOT HAZIRLIĞI (58% - 70%)
            # =========================================================================
            self.current_stage = "Sistem sanal bağlamaları yapılandırılıyor..."
            self.log("Sanal dosya sistemleri (/dev, /proc, /sys, /run) chroot hedefine bağlanıyor...")
            for b_dir in ["dev", "dev/pts", "proc", "sys", "run"]:
                self._exec(["mkdir", "-p", f"/target/{b_dir}"], check=False)
                self._exec(["mount", "--bind", f"/{b_dir}", f"/target/{b_dir}"], check=False)

            # DNS Çözümleme için resolv.conf
            self._exec(["cp", "-L", "/etc/resolv.conf", "/target/etc/resolv.conf"], check=False)

            # fstab Üretimi (UUID bazlı)
            self.log("Otomatik /etc/fstab dosyası UUID bilgileriyle oluşturuluyor...")
            esp_uuid = "1234-ABCD"
            root_uuid = "abcd1234-5678-90ab-cdef-0123456789ab"
            if not self.is_simulation:
                out_esp = subprocess.run(["blkid", "-s", "UUID", "-o", "value", esp_partition], capture_output=True, text=True)
                out_root = subprocess.run(["blkid", "-s", "UUID", "-o", "value", active_root_device], capture_output=True, text=True)
                if out_esp.stdout.strip():
                    esp_uuid = out_esp.stdout.strip()
                if out_root.stdout.strip():
                    root_uuid = out_root.stdout.strip()

            fstab_lines = [
                "# /etc/fstab: static file system information created by ParsLinux Setup",
                "# <file system> <mount point>   <type>  <options>       <dump>  <pass>"
            ]
            if fs_type == "btrfs":
                fstab_lines.append(f"UUID={root_uuid} / btrfs rw,noatime,compress=zstd:1,space_cache=v2,subvol=@ 0 0")
                fstab_lines.append(f"UUID={root_uuid} /home btrfs rw,noatime,compress=zstd:1,space_cache=v2,subvol=@home 0 0")
                fstab_lines.append(f"UUID={root_uuid} /.snapshots btrfs rw,noatime,compress=zstd:1,space_cache=v2,subvol=@snapshots 0 0")
            else:
                fstab_lines.append(f"UUID={root_uuid} / ext4 errors=remount-ro,noatime 0 1")

            fstab_lines.append(f"UUID={esp_uuid} /boot/efi vfat umask=0077 0 2")
            if swap_type == "file":
                fstab_lines.append("/swapfile none swap sw 0 0")

            fstab_content = "\n".join(fstab_lines) + "\n"
            if not self.is_simulation:
                os.makedirs("/target/etc", exist_ok=True)
                with open("/target/etc/fstab", "w", encoding="utf-8") as f:
                    f.write(fstab_content)
            self.log(f"fstab yazıldı:\n{fstab_content}")

            # Crypttab (Eğer LUKS etkinse)
            if luks_enabled:
                raw_root_uuid = root_uuid
                if not self.is_simulation:
                    out_raw = subprocess.run(["blkid", "-s", "UUID", "-o", "value", root_partition], capture_output=True, text=True)
                    if out_raw.stdout.strip():
                        raw_root_uuid = out_raw.stdout.strip()
                crypttab_line = f"pars-root UUID={raw_root_uuid} none luks,discard\n"
                if not self.is_simulation:
                    with open("/target/etc/crypttab", "w", encoding="utf-8") as f:
                        f.write(crypttab_line)
                self.log(f"crypttab yazıldı: {crypttab_line.strip()}")

            self._update_progress(70)

            # =========================================================================
            # AŞAMA 4: YERELLEŞTİRME VE KULLANICI AYARLARI (70% - 85%)
            # =========================================================================
            self.current_stage = "Kullanıcı hesapları ve yerel ayarlar yapılandırılıyor..."
            
            # Hostname & Hosts
            self.log(f"Hostname tanımlanıyor: {hostname}...")
            if not self.is_simulation:
                with open("/target/etc/hostname", "w", encoding="utf-8") as f:
                    f.write(f"{hostname}\n")
                hosts_content = f"127.0.0.1\tlocalhost\n127.0.1.1\t{hostname}\n::1\tlocalhost ip6-localhost ip6-loopback\n"
                with open("/target/etc/hosts", "w", encoding="utf-8") as f:
                    f.write(hosts_content)

            # Saat Dilimi ve RTC
            self.log(f"Saat dilimi yapılandırılıyor: {timezone}...")
            self._exec(["ln", "-sf", f"/usr/share/zoneinfo/{timezone}", "/target/etc/localtime"], check=False)
            if not self.is_simulation:
                with open("/target/etc/timezone", "w", encoding="utf-8") as f:
                    f.write(f"{timezone}\n")

            if has_windows or mode == "alongside":
                self.log("Dual-Boot Uyum Modu: Donanım saati (RTC) LOCAL olarak ayarlandı.")
                self._exec(["chroot", "/target", "timedatectl", "set-local-rtc", "1"], check=False)
            else:
                self.log("Donanım saati (RTC) evrensel UTC olarak yapılandırıldı.")

            # Klavye Düzeni
            self.log(f"Klavye konsol haritası yazılıyor: {kb_layout}...")
            kb_content = f'XKBLAYOUT="{kb_layout}"\nXKBMODEL="pc105"\nXKBVARIANT=""\nXKBOPTIONS=""\n'
            if not self.is_simulation:
                os.makedirs("/target/etc/default", exist_ok=True)
                with open("/target/etc/default/keyboard", "w", encoding="utf-8") as f:
                    f.write(kb_content)

            # Yerel Dil (Locale)
            self.log(f"Dil üretiliyor: {locale}...")
            if not self.is_simulation:
                with open("/target/etc/default/locale", "w", encoding="utf-8") as f:
                    f.write(f'LANG="{locale}"\nLANGUAGE="{locale.split(".")[0]}"\n')
            self._exec(["chroot", "/target", "locale-gen", locale], check=False)

            # Kullanıcı Oluşturma
            if is_oem:
                self.log("OEM KURULUM MODU: Üretici ön-kurulum yapılandırması etkinleştirildi.")
                self._exec(["chroot", "/target", "useradd", "-m", "-s", "/bin/bash", "-G", "sudo,adm,cdrom,dip,plugdev", "oem"], check=False)
                self._exec(["chroot", "/target", "chpasswd"], input_str="oem:oem\n", check=False)
                if not self.is_simulation:
                    with open("/target/etc/oem-config", "w") as f:
                        f.write("1\n")
            else:
                self.log(f"Kullanıcı hesabı oluşturuluyor: '{username}' ({fullname})...")
                self._exec([
                    "chroot", "/target", "useradd", "-m", "-s", "/bin/bash",
                    "-G", "sudo,adm,cdrom,dip,plugdev,users",
                    "-c", fullname, username
                ], check=False)

                if password:
                    self._exec(["chroot", "/target", "chpasswd"], input_str=f"{username}:{password}\n", check=False)
                    if rootsame:
                        self._exec(["chroot", "/target", "chpasswd"], input_str=f"root:{password}\n", check=False)

                # Otomatik Giriş (Autologin)
                if autologin:
                    self.log(f"Otomatik masaüstü girişi etkinleştirildi: {username}")
                    lightdm_conf = f"[Seat:*]\nautologin-user={username}\nautologin-user-timeout=0\n"
                    if not self.is_simulation:
                        os.makedirs("/target/etc/lightdm/lightdm.conf.d", exist_ok=True)
                        with open("/target/etc/lightdm/lightdm.conf.d/99-pars-autologin.conf", "w") as f:
                            f.write(lightdm_conf)

            self._update_progress(85)

            # =========================================================================
            # AŞAMA 5: ÖNYÜKLEYİCİ (GRUB EFI) VE BİTİRİŞ (85% - 100%)
            # =========================================================================
            self.current_stage = "GRUB EFI önyükleyici sisteme kuruluyor..."
            self.log("initramfs çekirdek imajı güncelleniyor (update-initramfs -u)...")
            self._exec(["chroot", "/target", "update-initramfs", "-u", "-k", "all"], check=False)
            time.sleep(0.5)

            self.log("GRUB EFI Bootloader kuruluyor: /boot/efi (parslinux)...")
            self._exec([
                "chroot", "/target", "grub-install",
                "--target=x86_64-efi",
                "--efi-directory=/boot/efi",
                "--bootloader-id=parslinux",
                "--recheck"
            ], check=False)

            self.log("Diğer işletim sistemleri taranıyor ve grub.cfg üretiliyor...")
            self._exec(["chroot", "/target", "update-grub"], check=False)
            self._update_progress(95)

            # Temizlik ve Senkronizasyon
            self.current_stage = "Kurulum tamamlanıyor, diskler senkronize ediliyor..."
            self.log("Disk önbelleği belleğe yazılıyor (sync)...")
            self._exec(["sync"], check=False)
            time.sleep(0.5)

            self.log("Geçici bağlama noktaları güvenle çözülüyor (umount -R /target)...")
            self._cleanup_mounts()

            self.current_stage = "Kurulum tamamlandı!"
            self.log("TEBRİKLER! ParsLinux kurulumu başarıyla tamamlandı.")
            self._update_progress(100)

            self.is_finished = True
            self.is_running = False

        except Exception as e:
            self.has_error = True
            self.error_message = str(e)
            self.is_running = False
            self.log(f"HATA: Kurulum sırasında beklenmeyen bir sorun oluştu: {e}")
            self._cleanup_mounts()

    def _update_progress(self, val: int):
        self.progress = min(100, max(0, val))

    def get_status(self) -> dict:
        """Mevcut durum özetini sözlük olarak döndürür."""
        new_logs = []
        while not self.logs_queue.empty():
            try:
                new_logs.append(self.logs_queue.get_nowait())
            except queue.Empty:
                break

        return {
            "is_running": self.is_running,
            "is_finished": self.is_finished,
            "has_error": self.has_error,
            "error_message": self.error_message,
            "progress": self.progress,
            "current_stage": self.current_stage,
            "new_logs": new_logs,
            "total_logs_count": len(self.all_logs)
        }
