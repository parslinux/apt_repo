"""
ParsLinux / Linux OS Kurulum Sihirbazı - Kullanıcı ve Güvenlik Yönetimi
"""

import re
import math
import hashlib


def sanitize_username(full_name: str) -> str:
    """Tam isimden geçerli ve temiz bir Linux kullanıcı adı üretir."""
    if not full_name:
        return "pars"
    
    # Türkçe karakter dönüştürme
    tr_map = str.maketrans("çğışöüÇĞİŞÖÜ", "cgisouCGISOU")
    clean = full_name.translate(tr_map).strip()
    first_part = clean.split()[0].lower()
    
    # Sadece harf, rakam ve tire/alt çizgi bırak
    user = re.sub(r"[^a-z0-9_-]", "", first_part)
    
    # İlk karakter harf olmalıdır
    if user and not user[0].isalpha():
        user = "u" + user
        
    return user[:16] if user else "pars"


def sanitize_hostname(username: str) -> str:
    """Kullanıcı adından bilgisayar adı (hostname) türetir."""
    clean_user = re.sub(r"[^a-zA-Z0-9-]", "", username).lower()
    return f"{clean_user}-pc" if clean_user else "parslinux-pc"


def evaluate_password(password: str) -> dict:
    """
    Parolanın gücünü analiz eder.
    Puan (0-100), seviye ('boş', 'zayıf', 'orta', 'güçlü') ve mesaj döndürür.
    """
    if not password:
        return {"score": 0, "level": "empty", "label": "Boş", "color": "slate", "valid": False}
        
    length = len(password)
    has_lower = bool(re.search(r"[a-z]", password))
    has_upper = bool(re.search(r"[A-Z]", password))
    has_digit = bool(re.search(r"\d", password))
    has_special = bool(re.search(r"[!@#$%^&*()_+\-=\[\]{};':\",.<>/?\\|]", password))
    
    score = 0
    score += min(length * 6, 40)
    if has_lower: score += 15
    if has_upper: score += 15
    if has_digit: score += 15
    if has_special: score += 15
    
    score = min(100, score)
    
    if length < 4:
        return {"score": score, "level": "too_short", "label": "Çok Kısa", "color": "red", "valid": False}
    elif score < 45:
        return {"score": score, "level": "weak", "label": "Zayıf", "color": "red", "valid": True}
    elif score < 75:
        return {"score": score, "level": "medium", "label": "Orta", "color": "amber", "valid": True}
    else:
        return {"score": score, "level": "strong", "label": "Çok Güçlü", "color": "emerald", "valid": True}


def validate_user_config(config: dict) -> dict:
    """Kullanıcı formundaki tüm alanları doğrular."""
    fullname = config.get("fullname", "").strip()
    username = config.get("username", "").strip()
    hostname = config.get("hostname", "").strip()
    password = config.get("password", "")
    
    errors = []
    
    if not fullname:
        errors.append("Tam ad alanı boş bırakılamaz.")
        
    if not re.match(r"^[a-z_][a-z0-9_-]{0,31}$", username):
        errors.append("Kullanıcı adı küçük harfle başlamalı ve yalnızca harf, rakam ve tire içermelidir.")
        
    if not re.match(r"^[a-zA-Z0-9][a-zA-Z0-9-]{0,62}$", hostname):
        errors.append("Bilgisayar adı (Hostname) geçersiz karakterler içeriyor.")
        
    pass_eval = evaluate_password(password)
    if not pass_eval["valid"]:
        errors.append("Parola en az 4 karakter olmalıdır.")
        
    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "password_strength": pass_eval
    }
