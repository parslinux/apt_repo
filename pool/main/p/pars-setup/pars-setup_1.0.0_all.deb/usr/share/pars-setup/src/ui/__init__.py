"""
ParsLinux Setup UI Package
"""
from .window import InstallerWindow
