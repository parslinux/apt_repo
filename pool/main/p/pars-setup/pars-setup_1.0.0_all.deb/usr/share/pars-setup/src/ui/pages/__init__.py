"""
ParsLinux Setup UI Pages Package
"""
from .page_welcome import PageWelcome
from .page_keyboard import PageKeyboard
from .page_timezone import PageTimezone
from .page_disk import PageDisk
from .page_users import PageUsers
from .page_summary import PageSummary
from .page_progress import PageProgress
from .page_finish import PageFinish
