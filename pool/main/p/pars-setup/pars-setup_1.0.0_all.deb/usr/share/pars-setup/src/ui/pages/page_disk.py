"""
ParsLinux Setup - 4. Adım: Disk Bölümleme Sayfası
Hedef disk seçimi, Dual-Boot (kaydırıcı), Diski Silme, LUKS2 şifreleme, dosya sistemi ve swap yönetimi.
"""

import subprocess
import shutil
import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw

from src.Config import _
from src.ui.widgets.disk_visualizer import DiskVisualizer


class PageDisk(Gtk.ScrolledWindow):
    def __init__(self, disks: list, on_disk_changed_callback=None, on_validation_changed_callback=None):
        super().__init__()
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.disks = disks
        self.on_disk_changed_callback = on_disk_changed_callback
        self.on_validation_changed_callback = on_validation_changed_callback

        self.selected_disk = disks[0] if disks else None
        self.selected_mode = "alongside"
        self.linux_disk_gb = 150

        self._build_ui()

    def _build_ui(self):
        clamp = Adw.Clamp()
        clamp.set_maximum_size(740)
        clamp.set_tightening_threshold(560)

        page_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)
        page_box.add_css_class("content-box")
        clamp.set_child(page_box)
        self.set_child(clamp)

        # Başlık
        title_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        h1 = Gtk.Label(label=_("Kurulum Türü ve Hedef Disk"), xalign=0)
        h1.add_css_class("title-1")
        sub = Gtk.Label(
            label=_("ParsLinux'un kurulacağı sabit depolama aygıtını ve disk bölümleme düzenini belirleyin."),
            wrap=True,
            xalign=0
        )
        sub.add_css_class("dim-label")
        title_vbox.append(h1)
        title_vbox.append(sub)
        page_box.append(title_vbox)

        # Hedef Disk Seçici Grubu
        group_disk = Adw.PreferencesGroup()
        group_disk.set_title(_("Depolama Aygıtı"))

        disk_names = [d["display_name"] for d in self.disks] if self.disks else ["Sanal NVMe SSD (512 GB)"]
        self.drop_target_disk = Gtk.DropDown.new_from_strings(disk_names)
        self.drop_target_disk.set_valign(Gtk.Align.CENTER)
        self.drop_target_disk.connect("notify::selected", self._on_disk_selected)

        row_disk = Adw.ActionRow(title=_("Hedef Sürücü"), subtitle=_("Kurulum yapılacak fiziksel disk"))
        row_disk.add_prefix(Gtk.Image.new_from_icon_name("drive-harddisk-symbolic"))
        row_disk.add_suffix(self.drop_target_disk)
        group_disk.add(row_disk)

        # S.M.A.R.T. Sağlık Durumu Satırı
        self.row_smart = Adw.ActionRow(title=_("S.M.A.R.T. Donanım Sağlığı"))
        self.img_smart_icon = Gtk.Image.new_from_icon_name("emblem-ok-symbolic")
        self.row_smart.add_prefix(self.img_smart_icon)
        self.lbl_smart_status = Gtk.Label(label="", xalign=1)
        self.lbl_smart_status.set_valign(Gtk.Align.CENTER)
        self.row_smart.add_suffix(self.lbl_smart_status)
        group_disk.add(self.row_smart)

        page_box.append(group_disk)

        # SMART Arıza Uyarısı Kartı (Gizli başlar, arıza tespitinde açılır)
        self.smart_warn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        self.smart_warn_box.add_css_class("warning-card")
        self.smart_warn_box.set_visible(False)
        w_ico = Gtk.Image.new_from_icon_name("dialog-warning-symbolic")
        w_ico.set_pixel_size(32)
        self.lbl_smart_warn = Gtk.Label(
            label=_(
                "DİKKAT: Seçilen diskte S.M.A.R.T. donanım arızası veya bozuk sektör riski tespit edildi! "
                "Bu diske kurulum yapmadan önce verilerinizi yedeklemeniz veya başka bir disk seçmeniz önemle tavsiye edilir."
            ),
            wrap=True,
            xalign=0
        )
        self.smart_warn_box.append(w_ico)
        self.smart_warn_box.append(self.lbl_smart_warn)
        page_box.append(self.smart_warn_box)

        # Kurulum Modları
        lbl_mode_title = Gtk.Label(label=_("Kurulum Düzeni Seçenekleri"), xalign=0)
        lbl_mode_title.add_css_class("heading")
        page_box.append(lbl_mode_title)

        # Mod 1: Dual-Boot Yan Yana Kur
        self.radio_alongside = Gtk.CheckButton.new_with_label(
            _("Mevcut İşletim Sistemi Yanına Kur (Dual-Boot)")
        )
        self.radio_alongside.set_active(True)
        self.radio_alongside.connect("toggled", lambda b: self._on_mode_toggled("alongside"))
        page_box.append(self.radio_alongside)

        # Dual-Boot Kaydırıcı ve Görsel Kartı
        self.slider_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.slider_card.add_css_class("info-card")

        self.lbl_slider_values = Gtk.Label(label="Mevcut OS: 312 GB   |   ParsLinux: 200 GB", xalign=0)
        self.lbl_slider_values.add_css_class("heading")
        self.slider_card.append(self.lbl_slider_values)

        total_gb = self.selected_disk["size_gb"] if self.selected_disk else 512
        max_alloc = max(40, total_gb - 20)
        self.scale_disk = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 30, max_alloc, 10)
        self.scale_disk.set_value(min(200, total_gb // 2))
        self.scale_disk.set_hexpand(True)
        self.scale_disk.connect("value-changed", self._on_slider_changed)
        self.slider_card.append(self.scale_disk)

        # Görsel Alan Çubuğu
        self.visualizer = DiskVisualizer()
        self.slider_card.append(self.visualizer)

        page_box.append(self.slider_card)

        # Mod 2: Diski Sil ve Temiz Kur
        self.radio_erase = Gtk.CheckButton.new_with_label(
            _("Diski Tamamen Sil ve ParsLinux Kur (Temiz Kurulum - Tüm veriler silinir)")
        )
        self.radio_erase.set_group(self.radio_alongside)
        self.radio_erase.connect("toggled", lambda b: self._on_mode_toggled("erase"))
        page_box.append(self.radio_erase)

        # Mod 3: Manuel Bölümleme
        self.radio_manual = Gtk.CheckButton.new_with_label(
            _("Manuel Bölümlendirme (Gelişmiş kullanıcılar için özel bağlama noktaları)")
        )
        self.radio_manual.set_group(self.radio_alongside)
        self.radio_manual.connect("toggled", lambda b: self._on_mode_toggled("manual"))
        page_box.append(self.radio_manual)

        # Manuel Mod GParted Butonu
        self.btn_gparted = Gtk.Button(label=_("GParted Bölüm Yöneticisini Başlat"))
        self.btn_gparted.set_visible(False)
        self.btn_gparted.connect("clicked", self._on_launch_gparted)
        page_box.append(self.btn_gparted)

        # Gelişmiş Depolama ve Güvenlik Ayarları (Dosya Sistemi, Swap, LUKS)
        adv_group = Adw.PreferencesGroup()
        adv_group.set_title(_("Gelişmiş Dosya Sistemi ve Şifreleme (Opsiyonel)"))

        # 1. Dosya Sistemi
        self.fs_options = ["ext4 (Kararlı ve Hızlı - Önerilen)", "Btrfs (Anlık Görüntü ve CoW Destekli)", "XFS"]
        self.drop_fs = Gtk.DropDown.new_from_strings(self.fs_options)
        self.drop_fs.set_valign(Gtk.Align.CENTER)
        self.drop_fs.set_selected(0)

        row_fs = Adw.ActionRow(title=_("Kök Dosya Sistemi"), subtitle=_("Yeni Linux bölümünün dosya formatı"))
        row_fs.add_prefix(Gtk.Image.new_from_icon_name("drive-harddisk-symbolic"))
        row_fs.add_suffix(self.drop_fs)
        adv_group.add(row_fs)

        # 2. Swap Yönetimi
        self.swap_options = ["zram (RAM Sıkıştırma - Modern ve Hızlı)", "Diskte Takas Dosyası (4 GB Swapfile)", "Takas Alanı Yok"]
        self.drop_swap = Gtk.DropDown.new_from_strings(self.swap_options)
        self.drop_swap.set_valign(Gtk.Align.CENTER)
        self.drop_swap.set_selected(0)

        row_swap = Adw.ActionRow(title=_("Takas (Swap) Alanı"), subtitle=_("Bellek yetersizliğinde kullanılacak alan"))
        row_swap.add_prefix(Gtk.Image.new_from_icon_name("memory-symbolic"))
        row_swap.add_suffix(self.drop_swap)
        adv_group.add(row_swap)

        # 3. LUKS2 Tam Disk Şifreleme (ExpanderRow)
        self.exp_luks = Adw.ExpanderRow(title=_("Diski Şifrele (LUKS2 Güvenliği)"))
        self.exp_luks.set_subtitle(_("Bilgisayar açılırken şifre çözme parolası istenir"))
        self.exp_luks.add_prefix(Gtk.Image.new_from_icon_name("security-high-symbolic"))
        self.exp_luks.set_show_enable_switch(True)
        self.exp_luks.set_enable_expansion(False)
        self.exp_luks.connect("notify::enable-expansion", self._on_luks_toggle)

        self.row_luks_pass = Adw.PasswordEntryRow(title=_("Şifreleme Parolası"))
        self.row_luks_pass.connect("changed", self._on_luks_pass_changed)
        self.row_luks_confirm = Adw.PasswordEntryRow(title=_("Parolayı Doğrulayın"))
        self.row_luks_confirm.connect("changed", self._on_luks_pass_changed)

        self.exp_luks.add_row(self.row_luks_pass)
        self.exp_luks.add_row(self.row_luks_confirm)
        adv_group.add(self.exp_luks)

        page_box.append(adv_group)

        self._update_slider_labels()
        self._update_smart_ui()

    def _update_smart_ui(self):
        if not self.selected_disk:
            self.lbl_smart_status.set_text(_("Disk Seçilmedi"))
            self.smart_warn_box.set_visible(False)
            return

        smart = self.selected_disk.get("smart", {})
        status_text = smart.get("status", _("Sağlık Bilgisi Alınamadı"))
        healthy = smart.get("healthy", True)
        supported = smart.get("supported", False)

        self.lbl_smart_status.set_text(status_text)
        if not healthy:
            self.img_smart_icon.set_from_icon_name("dialog-error-symbolic")
            self.smart_warn_box.set_visible(True)
        elif supported:
            self.img_smart_icon.set_from_icon_name("emblem-ok-symbolic")
            self.smart_warn_box.set_visible(False)
        else:
            self.img_smart_icon.set_from_icon_name("dialog-information-symbolic")
            self.smart_warn_box.set_visible(False)

    def _on_disk_selected(self, dropdown, param):
        idx = dropdown.get_selected()
        if idx < len(self.disks):
            self.selected_disk = self.disks[idx]
            total_gb = self.selected_disk["size_gb"]
            self.scale_disk.set_range(30, max(40, total_gb - 20))
            self.scale_disk.set_value(min(200, total_gb // 2))
            self._update_slider_labels()
            self._update_smart_ui()
            if self.on_disk_changed_callback:
                self.on_disk_changed_callback(self.selected_disk)

    def _on_mode_toggled(self, mode):
        self.selected_mode = mode
        self.slider_card.set_visible(mode == "alongside")
        self.btn_gparted.set_visible(mode == "manual")
        self._update_slider_labels()

    def _on_slider_changed(self, scale):
        self.linux_disk_gb = int(scale.get_value())
        self._update_slider_labels()

    def _on_luks_toggle(self, row, param):
        if self.on_validation_changed_callback:
            self.on_validation_changed_callback()

    def _on_luks_pass_changed(self, row):
        if self.on_validation_changed_callback:
            self.on_validation_changed_callback()

    def _on_launch_gparted(self, btn):
        if shutil.which("gparted"):
            subprocess.Popen(["gparted"])
        else:
            print("[*] GParted sistemde bulunamadı.")

    def _update_slider_labels(self):
        total = float(self.selected_disk["size_gb"] if self.selected_disk else 512.0)
        pars = float(self.linux_disk_gb)
        other = max(0.0, total - pars)
        self.lbl_slider_values.set_text(
            f"{_('Mevcut Sistem')}: {other:.0f} GB   |   ParsLinux: {pars:.0f} GB   ({_('Toplam')}: {total:.0f} GB)"
        )
        self.visualizer.update_allocation(total, pars, self.selected_mode)

    def is_valid(self) -> bool:
        if not self.selected_disk:
            return False
        if self.exp_luks.get_enable_expansion():
            p1 = self.row_luks_pass.get_text().strip()
            p2 = self.row_luks_confirm.get_text().strip()
            if not p1 or p1 != p2:
                return False
        return True

    def get_disk_config(self) -> dict:
        fs_str = "ext4"
        if self.drop_fs.get_selected() == 1:
            fs_str = "btrfs"
        elif self.drop_fs.get_selected() == 2:
            fs_str = "xfs"

        swap_str = "zram"
        if self.drop_swap.get_selected() == 1:
            swap_str = "file"
        elif self.drop_swap.get_selected() == 2:
            swap_str = "none"

        return {
            "disk": self.selected_disk,
            "mode": self.selected_mode,
            "linux_gb": self.linux_disk_gb,
            "filesystem": fs_str,
            "swap_type": swap_str,
            "luks_enabled": self.exp_luks.get_enable_expansion(),
            "luks_password": self.row_luks_pass.get_text() if self.exp_luks.get_enable_expansion() else "",
            "disk_path": self.selected_disk["path"] if self.selected_disk else "/dev/nvme0n1",
            "disk_name": self.selected_disk["name"] if self.selected_disk else "nvme0n1"
        }
