"""
ParsLinux Setup - 8. Adım: Kurulum Tamamlandı Sayfası
Başarı bildirimi, canlı oturumda kalma vs sistemi yeniden başlatma ve USB çıkarma uyarısı.
"""

import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw

from src.Config import _


class PageFinish(Gtk.ScrolledWindow):
    def __init__(self, on_stay_in_live_callback=None):
        super().__init__()
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.on_stay_in_live_callback = on_stay_in_live_callback
        self._build_ui()

    def _build_ui(self):
        clamp = Adw.Clamp()
        clamp.set_maximum_size(680)
        clamp.set_tightening_threshold(540)

        page_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        page_box.add_css_class("content-box")
        page_box.set_valign(Gtk.Align.CENTER)
        page_box.set_halign(Gtk.Align.CENTER)
        clamp.set_child(page_box)
        self.set_child(clamp)

        # Başarı İkonu
        icon = Gtk.Image.new_from_icon_name("emblem-ok-symbolic")
        icon.set_pixel_size(72)
        page_box.append(icon)

        # Başlık ve Açıklama
        h1 = Gtk.Label(label=_("Kurulum Başarıyla Tamamlandı!"))
        h1.add_css_class("title-1")
        page_box.append(h1)

        desc = Gtk.Label(
            label=_(
                "ParsLinux bilgisayarınıza başarıyla kuruldu.\n"
                "Yeni sisteminizi hemen kullanmak için bilgisayarınızı yeniden başlatabilir veya canlı oturumda kalabilirsiniz."
            ),
            justify=Gtk.Justification.CENTER
        )
        desc.add_css_class("dim-label")
        page_box.append(desc)

        # Yeniden Başlatma Kartı
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        card.add_css_class("info-card")
        
        self.chk_restart = Gtk.CheckButton.new_with_label(_("Sistemi şimdi yeniden başlat"))
        self.chk_restart.set_active(True)
        card.append(self.chk_restart)

        usb_note = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        u_icon = Gtk.Image.new_from_icon_name("media-removable-symbolic")
        u_lbl = Gtk.Label(label=_("Bilgisayar yeniden başlarken kurulum USB belleğini çıkarın."), xalign=0)
        u_lbl.add_css_class("dim-label")
        usb_note.append(u_icon)
        usb_note.append(u_lbl)
        card.append(usb_note)

        page_box.append(card)

        # Alternatif: Canlı Oturumda Kal Butonu
        btn_live = Gtk.Button(label=_("Canlı Masaüstünü Kullanmaya Devam Et"))
        btn_live.connect("clicked", self._on_stay_live_clicked)
        page_box.append(btn_live)

    def _on_stay_live_clicked(self, btn):
        if self.on_stay_in_live_callback:
            self.on_stay_in_live_callback()

    def is_restart_requested(self) -> bool:
        return self.chk_restart.get_active()
