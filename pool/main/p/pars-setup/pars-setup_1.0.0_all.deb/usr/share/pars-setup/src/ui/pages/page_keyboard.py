"""
ParsLinux Setup - 2. Adım: Klavye Düzeni Sayfası
Klavye modeli, dil varyantı seçimi, arama, otomatik algılama ve canlı klavye test girişi.
"""

import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw

from src.Config import _
from src.core.locales import KEYBOARD_LAYOUTS, apply_live_keyboard


class PageKeyboard(Gtk.ScrolledWindow):
    def __init__(self):
        super().__init__()
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.filtered_layouts = list(KEYBOARD_LAYOUTS)
        self._build_ui()

    def _build_ui(self):
        clamp = Adw.Clamp()
        clamp.set_maximum_size(740)
        clamp.set_tightening_threshold(560)

        page_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)
        page_box.add_css_class("content-box")
        clamp.set_child(page_box)
        self.set_child(clamp)

        # Başlık ve Otomatik Algıla Butonu
        title_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        
        title_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        h1 = Gtk.Label(label=_("Klavye Düzeninizi Seçin"), xalign=0)
        h1.add_css_class("title-1")
        sub = Gtk.Label(
            label=_("Sisteminiz ve oturum açma ekranınız için uygun klavye yerleşimini belirleyin."),
            wrap=True,
            xalign=0
        )
        sub.add_css_class("dim-label")
        title_vbox.append(h1)
        title_vbox.append(sub)
        title_box.append(title_vbox)

        spacer = Gtk.Box()
        spacer.set_hexpand(True)
        title_box.append(spacer)

        btn_detect = Gtk.Button(label=_("Klavyeyi Algıla"))
        btn_detect.set_valign(Gtk.Align.CENTER)
        btn_detect.connect("clicked", self._on_detect_clicked)
        title_box.append(btn_detect)

        page_box.append(title_box)

        # Arama Kutusu (Gtk.SearchEntry)
        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_placeholder_text(_("Klavye dili veya modeli ara (Türkçe, English, Deutsch vb.)..."))
        self.search_entry.connect("search-changed", self._on_search_changed)
        page_box.append(self.search_entry)

        # Klavye Seçim Grubu
        group = Adw.PreferencesGroup()
        group.set_title(_("Klavye Düzeni ve Varyantı"))

        # Model Seçici
        self.kb_models = [k["name"] for k in self.filtered_layouts]
        self.drop_kb_model = Gtk.DropDown.new_from_strings(self.kb_models)
        self.drop_kb_model.set_valign(Gtk.Align.CENTER)
        self.drop_kb_model.connect("notify::selected", self._on_model_changed)

        row_model = Adw.ActionRow(title=_("Klavye Dili / Modeli"), subtitle=_("Ana klavye dil ailesi"))
        row_model.add_prefix(Gtk.Image.new_from_icon_name("input-keyboard-symbolic"))
        row_model.add_suffix(self.drop_kb_model)
        group.add(row_model)

        # Varyant Seçici
        first_variants = [v["name"] for v in self.filtered_layouts[0]["variants"]]
        self.drop_kb_variant = Gtk.DropDown.new_from_strings(first_variants)
        self.drop_kb_variant.set_valign(Gtk.Align.CENTER)
        self.drop_kb_variant.connect("notify::selected", self._on_variant_changed)

        row_variant = Adw.ActionRow(title=_("Klavye Varyantı"), subtitle=_("Q, F, Dvorak veya bölgesel dizilim"))
        row_variant.add_prefix(Gtk.Image.new_from_icon_name("preferences-desktop-keyboard-symbolic"))
        row_variant.add_suffix(self.drop_kb_variant)
        group.add(row_variant)

        # NumLock Switch
        self.switch_numlock = Adw.SwitchRow(title=_("Açılışta NumLock Tuşunu Etkinleştir"))
        self.switch_numlock.set_subtitle(_("Sayısal tuş takımı varsayılan olarak açık başlar"))
        self.switch_numlock.set_active(True)
        group.add(self.switch_numlock)

        page_box.append(group)

        # Canlı Test Kartı
        test_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        test_card.add_css_class("info-card")

        lbl_test = Gtk.Label(
            label=_("Tuş vuruşlarınızı ve özel karakterleri (ç, ğ, ı, ö, ş, ü, @, #, €) burada test edebilirsiniz:"),
            wrap=True,
            xalign=0
        )
        test_card.append(lbl_test)

        self.ent_test = Gtk.Entry()
        self.ent_test.set_placeholder_text(_("Buraya bir şeyler yazarak klavyenizi test edin..."))
        test_card.append(self.ent_test)

        page_box.append(test_card)

    def _on_search_changed(self, entry):
        query = entry.get_text().strip().lower()
        if not query:
            self.filtered_layouts = list(KEYBOARD_LAYOUTS)
        else:
            self.filtered_layouts = [
                k for k in KEYBOARD_LAYOUTS
                if query in k["name"].lower() or any(query in v["name"].lower() for v in k["variants"])
            ]
            if not self.filtered_layouts:
                self.filtered_layouts = [KEYBOARD_LAYOUTS[0]]

        self.kb_models = [k["name"] for k in self.filtered_layouts]
        new_model = Gtk.StringList.new(self.kb_models)
        self.drop_kb_model.set_model(new_model)
        self.drop_kb_model.set_selected(0)
        self._on_model_changed(self.drop_kb_model, None)

    def _on_model_changed(self, dropdown, param):
        idx = dropdown.get_selected()
        if idx < len(self.filtered_layouts):
            kb = self.filtered_layouts[idx]
            variant_names = [v["name"] for v in kb["variants"]]
            new_model = Gtk.StringList.new(variant_names)
            self.drop_kb_variant.set_model(new_model)
            self.drop_kb_variant.set_selected(0)
            self._apply_current_selection()

    def _on_variant_changed(self, dropdown, param):
        self._apply_current_selection()

    def _apply_current_selection(self):
        m_idx = self.drop_kb_model.get_selected()
        v_idx = self.drop_kb_variant.get_selected()
        if m_idx < len(self.filtered_layouts):
            kb = self.filtered_layouts[m_idx]
            if v_idx < len(kb["variants"]):
                variant = kb["variants"][v_idx]
                apply_live_keyboard(kb["layout"], variant["id"])

    def _on_detect_clicked(self, btn):
        dialog = Adw.MessageDialog.new(
            self.get_root(),
            _("Klavye Algılama"),
            _("Klavyenizdeki 'Q' veya 'Z' tuşuna basarak düzeninizi doğrulayabilirsiniz. "
              "Varsayılan olarak 'Türkçe (Türkçe Q)' seçilmiştir.")
        )
        dialog.add_response("tr", _("Türkçe Q Seç"))
        dialog.add_response("tr-f", _("Türkçe F Seç"))
        dialog.add_response("us", _("English (US) Seç"))
        dialog.add_response("cancel", _("Vazgeç"))
        dialog.set_default_response("tr")

        def on_response(dlg, resp):
            if resp == "tr":
                self._select_by_layout("tr", "tr")
            elif resp == "tr-f":
                self._select_by_layout("tr", "tr-f")
            elif resp == "us":
                self._select_by_layout("us", "us")

        dialog.connect("response", on_response)
        dialog.present()

    def _select_by_layout(self, layout_id: str, variant_id: str):
        for idx, k in enumerate(self.filtered_layouts):
            if k["layout"] == layout_id:
                self.drop_kb_model.set_selected(idx)
                for v_idx, v in enumerate(k["variants"]):
                    if v["id"] == variant_id:
                        self.drop_kb_variant.set_selected(v_idx)
                        break
                break

    def get_selected_keyboard(self) -> dict:
        m_idx = self.drop_kb_model.get_selected()
        v_idx = self.drop_kb_variant.get_selected()
        model = self.filtered_layouts[m_idx] if m_idx < len(self.filtered_layouts) else KEYBOARD_LAYOUTS[0]
        variant = model["variants"][v_idx] if v_idx < len(model["variants"]) else model["variants"][0]
        return {
            "model_name": model["name"],
            "layout": model["layout"],
            "variant_name": variant["name"],
            "variant_id": variant["id"],
            "numlock": self.switch_numlock.get_active()
        }
