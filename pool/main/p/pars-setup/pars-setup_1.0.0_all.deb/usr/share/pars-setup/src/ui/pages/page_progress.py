"""
ParsLinux Setup - 7. Adım: Kurulum İlerlemesi Sayfası
Calamares tarzı zengin tanıtım slaytları, manuel gezinti butonları, log dışa aktarma ve canlı terminal konsolu.
"""

import os
import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw, GLib

from src.Config import DATA_DIR, _
from src.ui.widgets.terminal_viewer import TerminalViewer


class PageProgress(Gtk.ScrolledWindow):
    def __init__(self):
        super().__init__()
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)

        self.slides = [
            {
                "title": _("ParsLinux (Noble Pars)"),
                "badge": _("Sürüm Özeti & Tasarım"),
                "desc": _("Modern GTK4 ve Libadwaita teknolojileriyle inşa edilmiş, hızlı, akıcı ve göz yormayan modern Linux masaüstü."),
                "highlights": [
                    _("Özelleştirilmiş Linux çekirdeği ile anında tepki ve düşük gecikme"),
                    _("Kusursuz koyu tema uyumu ve hafif sistem bellek kullanımı"),
                    _("Kullanıma hazır zengin Türkçe yerelleştirme ve çoklu dil desteği")
                ],
                "icon": "parslinux-logo"
            },
            {
                "title": _("Tam Gizlilik ve Donanımsal Güvenlik"),
                "badge": _("Gizlilik & Güvenlik"),
                "desc": _("Arka planda telemetri servisleri veya veri toplayıcılar çalışmaz. Tüm kontrol ve kişisel verileriniz yalnızca sizindir."),
                "highlights": [
                    _("LUKS2 AES-256 ve Argon2id ile tam disk şifreleme"),
                    _("İzinsiz ağ trafiği ve arka plan servislerinden arındırılmış yapı"),
                    _("Systemd izolasyonu ve sandboxing güvenlik mimarisi")
                ],
                "icon": "security-high-symbolic"
            },
            {
                "title": _("Btrfs & Snapper ile Güvenli Geri Dönüş"),
                "badge": _("Modern Depolama"),
                "desc": _("Gelişmiş Btrfs Copy-on-Write (CoW) dosya sistemi ve Zstandard sıkıştırma ile yüksek hız ve disk alanı tasarrufu."),
                "highlights": [
                    _("Sistem güncellemelerinden önce otomatik anlık görüntü (snapshot)"),
                    _("Herhangi bir sorunda GRUB menüsünden eski ana anında dönüş"),
                    _("Zstandard (zstd:1) ile şeffaf ve yüksek verimli sıkıştırma")
                ],
                "icon": "drive-harddisk-symbolic"
            },
            {
                "title": _("Steam, Proton & Kusursuz Oyun Dünyası"),
                "badge": _("Oyun & Eğlence"),
                "desc": _("Güncel grafik sürücüleri, optimize edilmiş Vulkan API ve Valve Proton desteğiyle binlerce yerel ve Windows oyunu hazır."),
                "highlights": [
                    _("Steam, Heroic Games Launcher ve Lutris için hazır optimizasyonlar"),
                    _("PlayStation, Xbox ve üçüncü taraf kollar için tak-çalıştır sürücüler"),
                    _("PipeWire ile düşük gecikmeli profesyonel stüdyo ve oyun sesi")
                ],
                "icon": "input-gaming-symbolic"
            },
            {
                "title": _("Flathub & Gelişmiş Yazılım Ekosistemi"),
                "badge": _("Yazılım Dünyası"),
                "desc": _("İster profesyonel geliştirici, ister içerik üretici olun; ihtiyacınız olan tüm modern yazılımlar tek tıkla emrinizde."),
                "highlights": [
                    _("VS Code, Docker, Python, Rust ve Git geliştirme ortamları"),
                    _("Blender, GIMP, Inkscape, Krita ve OBS Studio içerik araçları"),
                    _("LibreOffice ofis paketi ve sandboxed Flatpak güvenliği")
                ],
                "icon": "system-software-install-symbolic"
            }
        ]
        self.current_slide_idx = 0
        self.collected_logs = []
        self._slide_timer_id = None

        self._build_ui()

    def _build_ui(self):
        clamp = Adw.Clamp()
        clamp.set_maximum_size(740)
        clamp.set_tightening_threshold(560)

        page_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        page_box.add_css_class("content-box")
        clamp.set_child(page_box)
        self.set_child(clamp)

        # Calamares Tarzı Zengin Slayt Kartı
        self.slide_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.slide_card.add_css_class("slide-card-rich")

        # Üst Rozet ve Sayaç
        top_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        self.slide_pill = Gtk.Label(label=self.slides[0]["badge"])
        self.slide_pill.add_css_class("slide-pill-badge")
        self.slide_counter = Gtk.Label(label=f"1 / {len(self.slides)}")
        self.slide_counter.add_css_class("slide-counter-badge")
        self.slide_counter.set_hexpand(True)
        self.slide_counter.set_xalign(1.0)
        top_bar.append(self.slide_pill)
        top_bar.append(self.slide_counter)
        self.slide_card.append(top_bar)

        # Orta Bölüm: Büyük İkon + Başlık ve Açıklamalar
        mid_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=18)
        self.slide_icon = Gtk.Image.new_from_icon_name(self.slides[0]["icon"])
        self.slide_icon.set_pixel_size(56)
        self.slide_icon.set_valign(Gtk.Align.START)
        mid_box.append(self.slide_icon)

        text_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        text_vbox.set_hexpand(True)

        self.slide_title = Gtk.Label(label=self.slides[0]["title"], xalign=0)
        self.slide_title.add_css_class("title-2")
        text_vbox.append(self.slide_title)

        self.slide_desc = Gtk.Label(label=self.slides[0]["desc"], wrap=True, xalign=0)
        self.slide_desc.add_css_class("dim-label")
        text_vbox.append(self.slide_desc)

        # Öne Çıkan 3 Madde (Highlights)
        self.highlight_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.highlight_box.set_margin_top(4)
        self.highlight_labels = []
        for _idx in range(3):
            h_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            h_row.add_css_class("slide-highlight-row")
            ico = Gtk.Image.new_from_icon_name("emblem-ok-symbolic")
            ico.set_pixel_size(14)
            lbl = Gtk.Label(label="", xalign=0, wrap=True)
            lbl.add_css_class("slide-highlight-row")
            h_row.append(ico)
            h_row.append(lbl)
            self.highlight_box.append(h_row)
            self.highlight_labels.append(lbl)

        text_vbox.append(self.highlight_box)
        mid_box.append(text_vbox)
        self.slide_card.append(mid_box)

        # Alt Gezinti: < [dots] >
        nav_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=14)
        nav_box.set_halign(Gtk.Align.CENTER)
        nav_box.set_margin_top(4)

        self.btn_prev_slide = Gtk.Button.new_from_icon_name("go-previous-symbolic")
        self.btn_prev_slide.add_css_class("slide-nav-btn")
        self.btn_prev_slide.set_tooltip_text(_("Önceki Tanıtım"))
        self.btn_prev_slide.connect("clicked", lambda b: self._prev_slide())
        nav_box.append(self.btn_prev_slide)

        self.dots_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.dots_box.set_valign(Gtk.Align.CENTER)
        self.dot_widgets = []
        for i in range(len(self.slides)):
            dot = Gtk.Box()
            dot.set_size_request(8, 8)
            dot.add_css_class("legend-dot-pars" if i == 0 else "legend-dot-existing")
            self.dots_box.append(dot)
            self.dot_widgets.append(dot)
        nav_box.append(self.dots_box)

        self.btn_next_slide = Gtk.Button.new_from_icon_name("go-next-symbolic")
        self.btn_next_slide.add_css_class("slide-nav-btn")
        self.btn_next_slide.set_tooltip_text(_("Sonraki Tanıtım"))
        self.btn_next_slide.connect("clicked", lambda b: self._next_slide())
        nav_box.append(self.btn_next_slide)

        self.slide_card.append(nav_box)
        page_box.append(self.slide_card)

        # İlk slayt içeriklerini yükle
        self._update_slide_display()

        # Hata Bildirim Kartı (Gizli başlar)
        self.error_card = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        self.error_card.add_css_class("warning-card")
        self.error_card.set_visible(False)
        e_icon = Gtk.Image.new_from_icon_name("dialog-error-symbolic")
        self.lbl_error = Gtk.Label(label="", wrap=True, xalign=0)
        self.error_card.append(e_icon)
        self.error_card.append(self.lbl_error)
        page_box.append(self.error_card)

        # İlerleme Bilgi Başlığı (Aşama Adı ve Yüzde)
        status_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        self.lbl_stage = Gtk.Label(label=_("Kurulum başlatılıyor..."), xalign=0)
        self.lbl_stage.add_css_class("heading")

        self.lbl_percent = Gtk.Label(label="%0", xalign=1)
        self.lbl_percent.set_hexpand(True)
        self.lbl_percent.add_css_class("heading")

        status_box.append(self.lbl_stage)
        status_box.append(self.lbl_percent)
        page_box.append(status_box)

        # İlerleme Çubuğu
        self.progress_bar = Gtk.ProgressBar()
        self.progress_bar.set_fraction(0.0)
        page_box.append(self.progress_bar)

        # Logları Dışa Aktar Butonu
        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.btn_export_logs = Gtk.Button(label=_("Günlüğü Dışa Aktar (Kaydet)"))
        self.btn_export_logs.connect("clicked", self._on_export_logs_clicked)
        btn_box.append(self.btn_export_logs)
        page_box.append(btn_box)

        # Terminal Log Konsolu (Açılır/Kapanır)
        self.terminal_viewer = TerminalViewer()
        page_box.append(self.terminal_viewer)

    def start_slide_timer(self):
        """Her 7 saniyede bir slaytları otomatik döndürür."""
        if not self._slide_timer_id:
            self._slide_timer_id = GLib.timeout_add_seconds(7, self._on_slide_tick)

    def _reset_slide_timer(self):
        if self._slide_timer_id:
            GLib.source_remove(self._slide_timer_id)
            self._slide_timer_id = None
        self.start_slide_timer()

    def _prev_slide(self):
        self.current_slide_idx = (self.current_slide_idx - 1) % len(self.slides)
        self._update_slide_display()
        self._reset_slide_timer()

    def _next_slide(self):
        self.current_slide_idx = (self.current_slide_idx + 1) % len(self.slides)
        self._update_slide_display()
        self._reset_slide_timer()

    def _on_slide_tick(self):
        self.current_slide_idx = (self.current_slide_idx + 1) % len(self.slides)
        self._update_slide_display()
        return True

    def _update_slide_display(self):
        cur = self.slides[self.current_slide_idx]
        self.slide_title.set_text(cur["title"])
        self.slide_desc.set_text(cur["desc"])
        self.slide_pill.set_text(cur["badge"])
        self.slide_counter.set_text(f"{self.current_slide_idx + 1} / {len(self.slides)}")

        icon_name = cur["icon"]
        logo_file = os.path.join(DATA_DIR, f"{icon_name}.svg")
        if os.path.exists(logo_file):
            self.slide_icon.set_from_file(logo_file)
        else:
            self.slide_icon.set_from_icon_name(icon_name)

        highlights = cur.get("highlights", [])
        for i, lbl in enumerate(self.highlight_labels):
            if i < len(highlights):
                lbl.set_text(highlights[i])
                lbl.get_parent().set_visible(True)
            else:
                lbl.get_parent().set_visible(False)

        for i, dot in enumerate(self.dot_widgets):
            dot.remove_css_class("legend-dot-pars")
            dot.remove_css_class("legend-dot-existing")
            dot.add_css_class("legend-dot-pars" if i == self.current_slide_idx else "legend-dot-existing")

    def update_progress(self, percent: int, stage_text: str, new_logs: list):
        self.progress_bar.set_fraction(percent / 100.0)
        self.lbl_percent.set_text(f"%{percent}")
        self.lbl_stage.set_text(stage_text)

        for line in new_logs:
            self.collected_logs.append(line)
            self.terminal_viewer.append_log(line)

    def show_error(self, message: str):
        self.lbl_error.set_text(message)
        self.error_card.set_visible(True)

    def _on_export_logs_clicked(self, btn):
        log_text = "\n".join(self.collected_logs)
        export_path = os.path.expanduser("~/pars-install.log")
        try:
            with open(export_path, "w", encoding="utf-8") as f:
                f.write(log_text)
            btn.set_label(_("Günlük Kaydedildi: ~/pars-install.log"))
        except Exception as e:
            btn.set_label(_("Kaydedilemedi: ") + str(e))
