"""
ParsLinux Setup - 6. Adım: Kurulum Özeti ve Onay Sayfası
Tüm yapılandırmaların teyit edilmesi, teknik bölümleme planı ve adımlara hızlı geri dönme.
"""

import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw

from src.Config import IS_SIMULATION, _


class PageSummary(Gtk.ScrolledWindow):
    def __init__(self, on_jump_step_callback=None):
        super().__init__()
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.on_jump_step_callback = on_jump_step_callback
        self._build_ui()

    def _build_ui(self):
        clamp = Adw.Clamp()
        clamp.set_maximum_size(740)
        clamp.set_tightening_threshold(560)

        page_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)
        page_box.add_css_class("content-box")
        clamp.set_child(page_box)
        self.set_child(clamp)

        # Başlık
        title_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        h1 = Gtk.Label(label=_("Kurulum Özeti ve Onay"), xalign=0)
        h1.add_css_class("title-1")
        sub = Gtk.Label(
            label=_("Lütfen ayarları dikkatlice inceleyin. 'Şimdi Kur' butonuna tıkladığınızda kurulum başlatılacaktır."),
            wrap=True,
            xalign=0
        )
        sub.add_css_class("dim-label")
        title_vbox.append(h1)
        title_vbox.append(sub)
        page_box.append(title_vbox)

        # Özet Grubu (Adw.PreferencesGroup)
        group = Adw.PreferencesGroup()
        group.set_title(_("Seçilen Kurulum Parametreleri"))

        # 1. Konum (Adım 3'e atlar)
        self.row_loc = Adw.ActionRow(title=_("Konum ve Saat"))
        self.row_loc.add_prefix(Gtk.Image.new_from_icon_name("mark-location-symbolic"))
        btn_edit_loc = Gtk.Button(label=_("Değiştir"))
        btn_edit_loc.set_valign(Gtk.Align.CENTER)
        btn_edit_loc.connect("clicked", lambda b: self._jump(3))
        self.row_loc.add_suffix(btn_edit_loc)
        group.add(self.row_loc)

        # 2. Klavye (Adım 2'ye atlar)
        self.row_kb = Adw.ActionRow(title=_("Klavye Düzeni"))
        self.row_kb.add_prefix(Gtk.Image.new_from_icon_name("input-keyboard-symbolic"))
        btn_edit_kb = Gtk.Button(label=_("Değiştir"))
        btn_edit_kb.set_valign(Gtk.Align.CENTER)
        btn_edit_kb.connect("clicked", lambda b: self._jump(2))
        self.row_kb.add_suffix(btn_edit_kb)
        group.add(self.row_kb)

        # 3. Kullanıcı (Adım 5'e atlar)
        self.row_user = Adw.ActionRow(title=_("Kullanıcı Hesabı"))
        self.row_user.add_prefix(Gtk.Image.new_from_icon_name("system-users-symbolic"))
        btn_edit_user = Gtk.Button(label=_("Değiştir"))
        btn_edit_user.set_valign(Gtk.Align.CENTER)
        btn_edit_user.connect("clicked", lambda b: self._jump(5))
        self.row_user.add_suffix(btn_edit_user)
        group.add(self.row_user)

        # 4. Disk (Adım 4'e atlar)
        self.row_disk = Adw.ActionRow(title=_("Bölümleme ve Hedef Disk"))
        self.row_disk.add_prefix(Gtk.Image.new_from_icon_name("drive-harddisk-symbolic"))
        btn_edit_disk = Gtk.Button(label=_("Değiştir"))
        btn_edit_disk.set_valign(Gtk.Align.CENTER)
        btn_edit_disk.connect("clicked", lambda b: self._jump(4))
        self.row_disk.add_suffix(btn_edit_disk)
        group.add(self.row_disk)

        # 5. Önyükleyici
        self.row_boot = Adw.ActionRow(title=_("Önyükleyici (GRUB)"), subtitle="UEFI ESP (/boot/efi)")
        self.row_boot.add_prefix(Gtk.Image.new_from_icon_name("computer-symbolic"))
        group.add(self.row_boot)

        page_box.append(group)

        # Teknik Bölümleme Özeti Kartı
        tech_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        tech_card.add_css_class("info-card")

        t_title = Gtk.Label(label=_("Teknik Bölümleme ve Dosya Sistemi Planı:"), xalign=0)
        t_title.add_css_class("heading")
        tech_card.append(t_title)

        self.lbl_p1 = Gtk.Label(label="• EFI Sistem Bölümü: /boot/efi (512 MB, FAT32, ESP)", xalign=0)
        self.lbl_p1.add_css_class("dim-label")
        self.lbl_p2 = Gtk.Label(label="• Kök Dosya Sistemi: / (ext4, Standart)", xalign=0)
        self.lbl_p2.add_css_class("dim-label")
        self.lbl_p3 = Gtk.Label(label="• Takas Alanı: zram (RAM Sıkıştırma)", xalign=0)
        self.lbl_p3.add_css_class("dim-label")
        self.lbl_p4 = Gtk.Label(label="• Şifreleme: Devre Dışı", xalign=0)
        self.lbl_p4.add_css_class("dim-label")

        tech_card.append(self.lbl_p1)
        tech_card.append(self.lbl_p2)
        tech_card.append(self.lbl_p3)
        tech_card.append(self.lbl_p4)
        page_box.append(tech_card)

        # Uyarı / Bilgilendirme Kartı
        warn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=14)
        if IS_SIMULATION:
            warn_box.add_css_class("simulation-card")
            w_icon = Gtk.Image.new_from_icon_name("security-high-symbolic")
            w_icon.set_pixel_size(32)
            w_text = Gtk.Label(
                label=_(
                    "GÜVENLİ SİMÜLASYON MODU ETKİN: Şu an güvenli simülasyon/deneme modundasınız. "
                    "Gerçek disklerinize veya verilerinize kesinlikle dokunulmaz. "
                    "'Şimdi Kur' butonuna bastığınızda disk biçimlendirme, paket açılımı, sürücü kurulumu ve GRUB yapılandırmaları güvenle simüle edilecektir."
                ),
                wrap=True,
                xalign=0
            )
        else:
            warn_box.add_css_class("warning-card")
            w_icon = Gtk.Image.new_from_icon_name("dialog-warning-symbolic")
            w_icon.set_pixel_size(32)
            w_text = Gtk.Label(
                label=_(
                    "DİKKAT: 'Şimdi Kur' butonuna tıkladığınızda seçilen diske format atılacak ve bölümler yeniden yapılandırılacaktır. "
                    "Diskteki önemli verilerinizi yedeklediğinizden emin olun. Bu aşamadan sonra işlem geri alınamaz."
                ),
                wrap=True,
                xalign=0
            )
        warn_box.append(w_icon)
        warn_box.append(w_text)
        page_box.append(warn_box)

    def _jump(self, step_number: int):
        if self.on_jump_step_callback:
            self.on_jump_step_callback(step_number)

    def update_summary(self, full_config: dict):
        # Konum
        tz = full_config.get("timezone", {})
        self.row_loc.set_subtitle(f"{tz.get('region', 'Europe')} / {tz.get('city', 'Istanbul')} ({tz.get('label', 'UTC+3')})")

        # Klavye
        kb = full_config.get("keyboard", {})
        self.row_kb.set_subtitle(f"{kb.get('model_name', 'Türkçe')} - {kb.get('variant_name', 'Türkçe Q')}")

        # Kullanıcı
        usr = full_config.get("user", {})
        if usr.get("is_oem"):
            self.row_user.set_subtitle(_("OEM Ön-Kurulum (Son kullanıcı hesabı ilk açılışta yapılandırılacak)"))
        else:
            self.row_user.set_subtitle(f"{usr.get('username', 'pars')} ({usr.get('hostname', 'parslinux-pc')})")

        # Disk
        d = full_config.get("disk", {})
        mode = d.get("mode", "alongside")
        d_path = d.get("disk_path", "/dev/nvme0n1")
        fs = d.get("filesystem", "ext4").upper()
        if mode == "erase":
            txt = f"{_('Tüm Diski Sil ve Temiz Kur')} ({d_path}) - {fs}"
        elif mode == "manual":
            txt = f"{_('Manuel Bölümlendirme')} ({d_path})"
        else:
            gb = d.get("linux_gb", 150)
            txt = f"{_('Dual-Boot Yan Yana')} ({gb} GB • {d_path}) - {fs}"
        self.row_disk.set_subtitle(txt)

        # Teknik detay güncelleme
        self.lbl_p2.set_text(f"• Kök Dosya Sistemi: / ({fs})")
        swap_str = d.get("swap_type", "zram")
        self.lbl_p3.set_text(f"• Takas (Swap): {swap_str}")
        luks = d.get("luks_enabled", False)
        self.lbl_p4.set_text(f"• LUKS2 Disk Şifreleme: {_('Etkin (Parola Korumalı)') if luks else _('Devre Dışı')}")
