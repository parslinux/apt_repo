"""
ParsLinux Setup - 3. Adım: Konum ve Saat Dilimi Sayfası
İnteraktif Cairo dünya haritası, arama, NTP ağ zaman eşitlemesi ve saat dilimi yönetimi.
"""

import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
import threading
from gi.repository import Gtk, Adw, GLib

from src.Config import _
from src.core.locales import TIMEZONES, detect_geoip_timezone
from src.ui.widgets.map_widget import TimezoneMapWidget


class PageTimezone(Gtk.ScrolledWindow):
    def __init__(self):
        super().__init__()
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.all_cities_flat = []
        for reg, clist in TIMEZONES.items():
            for c in clist:
                self.all_cities_flat.append((reg, c))

        self._build_ui()
        # Calamares / Pardus Standardı: Arka planda GeoIP ile otomatik konum tespiti
        threading.Thread(target=self._async_geoip_lookup, daemon=True).start()

    def _async_geoip_lookup(self):
        res = detect_geoip_timezone()
        if res.get("success"):
            GLib.idle_add(self._apply_geoip_result, res)

    def _apply_geoip_result(self, res: dict):
        reg = res.get("region")
        city = res.get("city")
        for r, c in self.all_cities_flat:
            if r == reg and c["city"].lower() == city.lower():
                self._on_map_city_clicked(r, c)
                self.map_widget.set_selected_location(r, c["city"])
                break

    def _build_ui(self):
        clamp = Adw.Clamp()
        clamp.set_maximum_size(740)
        clamp.set_tightening_threshold(560)

        page_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        page_box.add_css_class("content-box")
        clamp.set_child(page_box)
        self.set_child(clamp)

        # Başlık
        title_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        h1 = Gtk.Label(label=_("Konum ve Saat Dilimi"), xalign=0)
        h1.add_css_class("title-1")
        sub = Gtk.Label(
            label=_("Haritaya tıklayarak veya listeden aratarak bulunduğunuz konumu seçin."),
            wrap=True,
            xalign=0
        )
        sub.add_css_class("dim-label")
        title_vbox.append(h1)
        title_vbox.append(sub)
        page_box.append(title_vbox)

        # Şehir Arama Kutusu (SearchEntry)
        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_placeholder_text(_("Şehir veya saat dilimi ara (İstanbul, Berlin, New York vb.)..."))
        self.search_entry.connect("search-changed", self._on_search_changed)
        page_box.append(self.search_entry)

        # İNTERAKTİF DÜNYA HARİTASI (TimezoneMapWidget)
        map_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        map_card.add_css_class("info-card")
        map_card.set_size_request(-1, 230)

        self.map_widget = TimezoneMapWidget(on_city_clicked_callback=self._on_map_city_clicked)
        map_card.append(self.map_widget)
        page_box.append(map_card)

        # Seçim Grubu
        group = Adw.PreferencesGroup()
        group.set_title(_("Bölgesel Zaman Ayarları"))

        self.regions = list(TIMEZONES.keys())
        self.drop_region = Gtk.DropDown.new_from_strings(self.regions)
        self.drop_region.set_valign(Gtk.Align.CENTER)
        self.drop_region.connect("notify::selected", self._on_region_changed)

        row_reg = Adw.ActionRow(title=_("Coğrafi Bölge"), subtitle=_("Kıta veya ana saat havzası"))
        row_reg.add_prefix(Gtk.Image.new_from_icon_name("mark-location-symbolic"))
        row_reg.add_suffix(self.drop_region)
        group.add(row_reg)

        first_cities = [c["label"] for c in TIMEZONES[self.regions[0]]]
        self.drop_city = Gtk.DropDown.new_from_strings(first_cities)
        self.drop_city.set_valign(Gtk.Align.CENTER)
        self.drop_city.connect("notify::selected", self._on_city_changed)

        row_city = Adw.ActionRow(title=_("Şehir / Saat Dilimi"), subtitle=_("Referans şehir ve UTC farkı"))
        row_city.add_prefix(Gtk.Image.new_from_icon_name("preferences-system-time-symbolic"))
        row_city.add_suffix(self.drop_city)
        group.add(row_city)

        # NTP Switch (Ağ Saati Eşitleme)
        self.switch_ntp = Adw.SwitchRow(title=_("Saati İnternet Üzerinden Otomatik Ayarla (NTP)"))
        self.switch_ntp.set_subtitle(_("Network Time Protocol sunucuları ile anlık senkronizasyon"))
        self.switch_ntp.set_active(True)
        group.add(self.switch_ntp)

        # 24 Saat Biçimi
        self.switch_24h = Adw.SwitchRow(title=_("24 Saat Biçimini Kullan"))
        self.switch_24h.set_subtitle(_("Örnek: 14:30 (Açık) veya 02:30 PM (Kapalı)"))
        self.switch_24h.set_active(True)
        group.add(self.switch_24h)

        page_box.append(group)

        # Bilgi Kartı
        self.card_tz = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.card_tz.add_css_class("info-card")

        self.lbl_selected_tz = Gtk.Label(
            label="Seçilen Saat Dilimi: Europe / Istanbul (UTC+3)",
            xalign=0
        )
        self.lbl_selected_tz.add_css_class("heading")
        self.card_tz.append(self.lbl_selected_tz)
        page_box.append(self.card_tz)

        # Varsayılan olarak Europe / Istanbul seç
        self._updating = True
        if "Europe" in self.regions:
            r_idx = self.regions.index("Europe")
            self.drop_region.set_selected(r_idx)
            eur_cities = TIMEZONES.get("Europe", [])
            for c_idx, c in enumerate(eur_cities):
                if c["city"] == "Istanbul":
                    self.drop_city.set_selected(c_idx)
                    break
        self._updating = False
        self._update_display()

    def _on_map_city_clicked(self, region_name: str, city_dict: dict):
        if self._updating:
            return
        self._updating = True
        try:
            if region_name in self.regions:
                r_idx = self.regions.index(region_name)
                self.drop_region.set_selected(r_idx)
                cities = TIMEZONES[region_name]
                new_model = Gtk.StringList.new([c["label"] for c in cities])
                self.drop_city.set_model(new_model)
                for c_idx, c in enumerate(cities):
                    if c["city"] == city_dict["city"]:
                        self.drop_city.set_selected(c_idx)
                        break
        finally:
            self._updating = False
        self._update_display()

    def _on_search_changed(self, entry):
        query = entry.get_text().strip().lower()
        if not query:
            return

        for reg, c in self.all_cities_flat:
            if query in c["city"].lower() or query in c["label"].lower():
                self._on_map_city_clicked(reg, c)
                self.map_widget.set_selected_location(reg, c["city"])
                break

    def _on_region_changed(self, dropdown, param):
        if self._updating:
            return
        self._updating = True
        try:
            reg_idx = dropdown.get_selected()
            if reg_idx < len(self.regions):
                reg_name = self.regions[reg_idx]
                cities = [c["label"] for c in TIMEZONES[reg_name]]
                new_model = Gtk.StringList.new(cities)
                self.drop_city.set_model(new_model)
                self.drop_city.set_selected(0)
        finally:
            self._updating = False
        self._update_display()

    def _on_city_changed(self, dropdown, param):
        if self._updating:
            return
        self._update_display()

    def _update_display(self):
        reg_idx = self.drop_region.get_selected()
        city_idx = self.drop_city.get_selected()
        if reg_idx < len(self.regions):
            reg_name = self.regions[reg_idx]
            cities = TIMEZONES[reg_name]
            if city_idx < len(cities):
                c = cities[city_idx]
                tz_id = f"{reg_name}/{c['city']}"
                time_str = ""
                try:
                    import zoneinfo
                    import datetime
                    zi = zoneinfo.ZoneInfo(tz_id)
                    now = datetime.datetime.now(zi)
                    time_fmt = "%H:%M" if self.switch_24h.get_active() else "%I:%M %p"
                    raw_offset = now.strftime("%z")
                    offset_fmt = f"UTC{raw_offset[:3]}:{raw_offset[3:]}" if len(raw_offset) == 5 else f"UTC{raw_offset}"
                    time_str = f" • {_('Yerel Saat')}: {now.strftime(time_fmt)} ({offset_fmt})"
                except Exception:
                    time_str = f" ({c['label']})"

                clean_city = c['city'].replace('_', ' ')
                self.lbl_selected_tz.set_text(f"{_('Seçilen Konum')}: {reg_name} / {clean_city}{time_str}")
                self.map_widget.set_selected_location(reg_name, c["city"])

    def get_selected_timezone(self) -> dict:
        reg_idx = self.drop_region.get_selected()
        city_idx = self.drop_city.get_selected()
        reg_name = self.regions[reg_idx] if reg_idx < len(self.regions) else "Europe"
        cities = TIMEZONES[reg_name]
        city_data = cities[city_idx] if city_idx < len(cities) else cities[0]
        return {
            "region": reg_name,
            "city": city_data["city"],
            "label": city_data["label"],
            "timezone_str": f"{reg_name}/{city_data['city']}",
            "ntp": self.switch_ntp.get_active(),
            "use_24h": self.switch_24h.get_active()
        }
