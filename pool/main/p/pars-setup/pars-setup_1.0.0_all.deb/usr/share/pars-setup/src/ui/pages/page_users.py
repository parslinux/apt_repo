"""
ParsLinux Setup - 5. Adım: Kullanıcı ve Güvenlik Sayfası
Kullanıcı hesabı oluşturma, otomatik ad/hostname, parola eşleşme denetimi ve canlı doğrulama.
"""

import re
import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw

from src.Config import _
from src.core.users import sanitize_username, sanitize_hostname, evaluate_password


class PageUsers(Gtk.ScrolledWindow):
    def __init__(self, on_validation_changed_callback=None, is_oem_default: bool = False):
        super().__init__()
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.on_validation_changed_callback = on_validation_changed_callback
        self.reserved_usernames = ["root", "bin", "daemon", "adm", "lp", "sync", "shutdown", "halt", "mail", "nobody"]
        self.is_oem_default = is_oem_default

        self._build_ui()

    def _build_ui(self):
        clamp = Adw.Clamp()
        clamp.set_maximum_size(740)
        clamp.set_tightening_threshold(560)

        page_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)
        page_box.add_css_class("content-box")
        clamp.set_child(page_box)
        self.set_child(clamp)

        # Başlık
        title_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        h1 = Gtk.Label(label=_("Kullanıcı Hesabı ve Güvenlik"), xalign=0)
        h1.add_css_class("title-1")
        sub = Gtk.Label(
            label=_("Sisteminizi kullanmak için birincil yönetici hesabınızı oluşturun."),
            wrap=True,
            xalign=0
        )
        sub.add_css_class("dim-label")
        title_vbox.append(h1)
        title_vbox.append(sub)
        page_box.append(title_vbox)

        # OEM Grubu
        oem_group = Adw.PreferencesGroup()
        self.switch_oem = Adw.SwitchRow(title=_("OEM Kurulum Modu (Üretici / Satıcı Ön-Kurulumu)"))
        self.switch_oem.set_subtitle(_("Son kullanıcı hesabı açmayı ilk çalıştırmaya erteler (oem-config)"))
        self.switch_oem.set_active(self.is_oem_default)
        self.switch_oem.connect("notify::active", self._on_oem_toggled)
        oem_group.add(self.switch_oem)
        page_box.append(oem_group)

        # Kullanıcı Bilgileri Grubu (Adw.PreferencesGroup)
        self.group_user = Adw.PreferencesGroup()
        self.group_user.set_title(_("Hesap Tanımları"))

        # 1. Ad Soyad
        self.row_fullname = Adw.EntryRow(title=_("Adınız ve Soyadınız"))
        self.row_fullname.set_text("Pars Kullanıcısı")
        self.row_fullname.connect("changed", self._on_fullname_changed)
        self.group_user.add(self.row_fullname)

        # 2. Kullanıcı Adı
        self.row_username = Adw.EntryRow(title=_("Kullanıcı Adı (Giriş için)"))
        self.row_username.set_text("pars")
        self.row_username.connect("changed", self._on_field_changed)
        self.group_user.add(self.row_username)

        # 3. Bilgisayar Adı (Hostname)
        self.row_hostname = Adw.EntryRow(title=_("Bilgisayarınızın Adı (Ağda görünen)"))
        self.row_hostname.set_text("parslinux-pc")
        self.row_hostname.connect("changed", self._on_field_changed)
        self.group_user.add(self.row_hostname)

        # 4. Parola
        self.row_password = Adw.PasswordEntryRow(title=_("Hesap Parolası"))
        self.row_password.connect("changed", self._on_password_changed)
        self.group_user.add(self.row_password)

        # 5. Parola Doğrulama (Zorunlu Linux Standardı)
        self.row_confirm = Adw.PasswordEntryRow(title=_("Parolayı Doğrulayın"))
        self.row_confirm.connect("changed", self._on_confirm_changed)
        self.group_user.add(self.row_confirm)

        page_box.append(self.group_user)

        # Uyarı ve Hata Mesajı Rozeti
        self.lbl_error = Gtk.Label(label="", xalign=0)
        self.lbl_error.add_css_class("caption")
        self.lbl_error.set_visible(False)
        page_box.append(self.lbl_error)

        # Parola Güç Göstergesi Kartı
        strength_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        strength_card.add_css_class("info-card")

        lbl_hdr = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        lbl_s_title = Gtk.Label(label=_("Parola Güç Seviyesi:"), xalign=0)
        self.lbl_strength = Gtk.Label(label=_("Orta"), xalign=1)
        self.lbl_strength.set_hexpand(True)
        self.lbl_strength.add_css_class("heading")
        lbl_hdr.append(lbl_s_title)
        lbl_hdr.append(self.lbl_strength)
        strength_card.append(lbl_hdr)

        self.progress_pwd = Gtk.ProgressBar()
        self.progress_pwd.set_fraction(0.60)
        self.progress_pwd.add_css_class("pwd-medium")
        strength_card.append(self.progress_pwd)

        self.lbl_pwd_hint = Gtk.Label(
            label=_("En az 6 karakter girilmelidir. Güçlü bir parola için büyük-küçük harf, rakam ve sembol kullanın."),
            wrap=True,
            xalign=0
        )
        self.lbl_pwd_hint.add_css_class("dim-label")
        strength_card.append(self.lbl_pwd_hint)

        page_box.append(strength_card)

        # Oturum Seçenekleri
        opts_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.chk_autologin = Gtk.CheckButton.new_with_label(_("Şifre sormadan doğrudan masaüstünü aç (Otomatik Giriş)"))
        self.chk_rootsame = Gtk.CheckButton.new_with_label(_("Bu parolayı yönetici (root / sudo) yetkisi için de kullan"))
        self.chk_rootsame.set_active(True)
        opts_box.append(self.chk_autologin)
        opts_box.append(self.chk_rootsame)
        page_box.append(opts_box)

    def _on_fullname_changed(self, row):
        name = row.get_text()
        user = sanitize_username(name)
        host = sanitize_hostname(user)
        self.row_username.set_text(user)
        self.row_hostname.set_text(host)
        self._validate_fields()

    def _on_field_changed(self, row):
        self._validate_fields()

    def _on_password_changed(self, row):
        pwd = row.get_text()
        ev = evaluate_password(pwd)
        score = ev["score"]
        self.progress_pwd.set_fraction(score / 100.0)
        self.lbl_strength.set_text(ev["label"])

        self.progress_pwd.remove_css_class("pwd-weak")
        self.progress_pwd.remove_css_class("pwd-medium")
        self.progress_pwd.remove_css_class("pwd-strong")
        if score < 40:
            self.progress_pwd.add_css_class("pwd-weak")
        elif score < 75:
            self.progress_pwd.add_css_class("pwd-medium")
        else:
            self.progress_pwd.add_css_class("pwd-strong")

        self._validate_fields()

    def _on_oem_toggled(self, switch, param):
        is_oem = self.switch_oem.get_active()
        self.group_user.set_sensitive(not is_oem)
        if is_oem:
            self.lbl_error.set_visible(False)
        self._validate_fields()

    def _on_confirm_changed(self, row):
        self._validate_fields()

    def _validate_fields(self):
        valid = self.is_valid()
        if self.on_validation_changed_callback:
            self.on_validation_changed_callback()

    def is_valid(self) -> bool:
        if self.switch_oem.get_active():
            self.lbl_error.set_visible(False)
            return True

        username = self.row_username.get_text().strip().lower()
        hostname = self.row_hostname.get_text().strip()
        pwd = self.row_password.get_text()
        confirm = self.row_confirm.get_text()

        # 1. Kullanıcı adı kural denetimi
        if not username:
            self._set_error_text(_("Kullanıcı adı boş bırakılamaz."))
            return False
        if not re.match(r"^[a-z][a-z0-9_-]*$", username):
            self._set_error_text(_("Kullanıcı adı küçük harfle başlamalı ve yalnızca harf, rakam, tire veya alt çizgi içermelidir."))
            return False
        if username in self.reserved_usernames:
            self._set_error_text(_("Bu kullanıcı adı sistem tarafından ayrılmıştır. Başka bir ad seçin."))
            return False

        # 2. Hostname kural denetimi
        if not hostname or not re.match(r"^[a-zA-Z0-9-]{1,63}$", hostname):
            self._set_error_text(_("Bilgisayar adı geçersiz karakterler içeremez."))
            return False

        # 3. Parola denetimi
        if len(pwd) < 4:
            self._set_error_text(_("Parola en az 4 karakter olmalıdır."))
            return False

        # 4. Parola eşleşme denetimi
        if pwd != confirm:
            self._set_error_text(_("Girilen parolalar birbiriyle eşleşmiyor!"))
            return False

        # Hata yok
        self.lbl_error.set_visible(False)
        return True

    def _set_error_text(self, text: str):
        self.lbl_error.set_text(f"⚠️ {text}")
        self.lbl_error.set_visible(True)

    def get_user_config(self) -> dict:
        is_oem = self.switch_oem.get_active()
        if is_oem:
            return {
                "is_oem": True,
                "fullname": "OEM Configuration",
                "username": "oem",
                "hostname": "parslinux-oem",
                "password": "oem",
                "autologin": True,
                "rootsame": True
            }
        return {
            "is_oem": False,
            "fullname": self.row_fullname.get_text() or "Pars Kullanıcısı",
            "username": self.row_username.get_text().strip().lower() or "pars",
            "hostname": self.row_hostname.get_text().strip() or "parslinux-pc",
            "password": self.row_password.get_text() or "",
            "autologin": self.chk_autologin.get_active(),
            "rootsame": self.chk_rootsame.get_active()
        }
