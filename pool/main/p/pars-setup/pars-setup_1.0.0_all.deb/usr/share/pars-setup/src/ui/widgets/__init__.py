"""
ParsLinux Setup UI Widgets Package
"""
from .sidebar import InstallerSidebar
from .terminal_viewer import TerminalViewer
from .disk_visualizer import DiskVisualizer
from .map_widget import TimezoneMapWidget
