"""
ParsLinux Setup - Disk Bölümleme Görselleştirici Bileşeni
Mevcut disk durumunu ve kurulum sonrası ayrılacak alanları renkli çubuklarla gösterir.
"""

import gi
gi.require_version('Gtk', '4.0')
from gi.repository import Gtk

from src.Config import _


class DiskVisualizer(Gtk.Box):
    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self._build_ui()

    def _build_ui(self):
        # Görsel Alan Çubuğu (Gtk.Box içindeki renkli bölmeler)
        self.bar_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self.bar_box.set_size_request(-1, 46)
        self.bar_box.add_css_class("disk-bar-container")
        self.bar_box.set_hexpand(True)

        self.box_existing = Gtk.Box()
        self.box_existing.add_css_class("disk-existing-slice")
        self.box_existing.set_hexpand(True)
        self.box_existing.set_halign(Gtk.Align.FILL)
        self.box_existing.set_valign(Gtk.Align.FILL)
        self.lbl_existing = Gtk.Label(label="Mevcut Sistem (200 GB)")
        self.lbl_existing.set_xalign(0.5)
        self.box_existing.append(self.lbl_existing)

        self.box_pars = Gtk.Box()
        self.box_pars.add_css_class("disk-pars-slice")
        self.box_pars.set_hexpand(True)
        self.box_pars.set_halign(Gtk.Align.FILL)
        self.box_pars.set_valign(Gtk.Align.FILL)
        self.lbl_pars = Gtk.Label(label="ParsLinux (150 GB)")
        self.lbl_pars.set_xalign(0.5)
        self.box_pars.append(self.lbl_pars)

        self.bar_box.append(self.box_existing)
        self.bar_box.append(self.box_pars)
        self.append(self.bar_box)

        # Açıklama Lejantı
        legend = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        
        leg1 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        dot1 = Gtk.Box()
        dot1.set_size_request(12, 12)
        dot1.set_valign(Gtk.Align.CENTER)
        dot1.add_css_class("legend-dot-existing")
        leg1.append(dot1)
        leg1.append(Gtk.Label(label=_("Mevcut İşletim Sistemi / Boş Alan"), xalign=0))

        leg2 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        dot2 = Gtk.Box()
        dot2.set_size_request(12, 12)
        dot2.set_valign(Gtk.Align.CENTER)
        dot2.add_css_class("legend-dot-pars")
        leg2.append(dot2)
        leg2.append(Gtk.Label(label=_("Yeni ParsLinux Kök Alanı (ext4)"), xalign=0))

        legend.append(leg1)
        legend.append(leg2)
        self.append(legend)

    def update_allocation(self, total_gb: float, pars_gb: float, mode: str = "alongside"):
        if mode == "erase":
            self.box_existing.set_visible(False)
            self.lbl_pars.set_text(f"ParsLinux - {_('Tüm Disk')} ({total_gb:.1f} GB)")
        else:
            self.box_existing.set_visible(True)
            existing_gb = max(0.0, total_gb - pars_gb)
            self.lbl_existing.set_text(f"{_('Mevcut Sistem')} ({existing_gb:.1f} GB)")
            self.lbl_pars.set_text(f"ParsLinux ({pars_gb:.1f} GB)")
