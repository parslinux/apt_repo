"""
ParsLinux Setup - İnteraktif Dünya Haritası ve Saat Dilimi Seçici (MapWidget)
Pardus Installer (17g / Calamares) Miller Projeksiyonu ve timezone.png teknolojisi uyarlaması.
"""

import os
import math
import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Gdk', '4.0')
gi.require_version('GdkPixbuf', '2.0')
from gi.repository import Gtk, Gdk, GdkPixbuf

try:
    import cairo
    FONT_NORMAL = getattr(cairo, "FONT_SLANT_NORMAL", 0)
    FONT_BOLD = getattr(cairo, "FONT_WEIGHT_BOLD", 1)
except Exception:
    FONT_NORMAL = 0
    FONT_BOLD = 1

from src.Config import DATA_DIR
from src.core.locales import TIMEZONES, MAP_SIZE


class TimezoneMapWidget(Gtk.Box):
    def __init__(self, on_city_clicked_callback=None):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.set_size_request(-1, 240)
        self.on_city_clicked_callback = on_city_clicked_callback

        self.current_region = "Europe"
        self.current_city = "Istanbul"
        self.marker_px = 454
        self.marker_py = 169
        self.marker_x_pct = (454 / MAP_SIZE[0]) * 100.0
        self.marker_y_pct = (169 / MAP_SIZE[1]) * 100.0

        self.cached_pixbuf = None
        self.cached_width = 0
        self.cached_height = 0

        # Pardus Harita Görseli (832 x 425 PNG)
        self.map_png_path = os.path.join(DATA_DIR, "timezone.png")
        if not os.path.exists(self.map_png_path):
            self.map_png_path = os.path.join(DATA_DIR, "world_map.svg")

        # Hızlı arama için düz liste
        self._refresh_timezones_cache()
        self._build_ui()

    def _refresh_timezones_cache(self):
        self.all_timezones = []
        for reg_name, cities in TIMEZONES.items():
            for c in cities:
                self.all_timezones.append(c)

    def _build_ui(self):
        # Çizim Alanı (Gtk.DrawingArea)
        self.drawing_area = Gtk.DrawingArea()
        self.drawing_area.set_vexpand(True)
        self.drawing_area.set_hexpand(True)
        self.drawing_area.set_draw_func(self._on_draw)
        self.append(self.drawing_area)

        # Fare Tıklama Algılayıcı (Pardus map_clicked eşleniği)
        click_gesture = Gtk.GestureClick()
        click_gesture.connect("released", self._on_map_clicked)
        self.drawing_area.add_controller(click_gesture)

    def _on_draw(self, area, cr, width, height):
        if width <= 10 or height <= 10:
            return

        # 1. Pardus Harita Görselini Çizim Alanına Ölçekle ve Çiz
        if not self.cached_pixbuf or self.cached_width != width or self.cached_height != height:
            if os.path.exists(self.map_png_path):
                try:
                    self.cached_pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                        self.map_png_path, width, height, False
                    )
                    self.cached_width = width
                    self.cached_height = height
                except Exception:
                    self.cached_pixbuf = None

        if self.cached_pixbuf:
            Gdk.cairo_set_source_pixbuf(cr, self.cached_pixbuf, 0, 0)
            cr.paint()
        else:
            # Yedek Zemin
            cr.set_source_rgb(0.04, 0.06, 0.1)
            cr.paint()

        # 2. Pardus Koordinatlarına Sahip Şehir Noktalarını Zarifçe Çiz
        cr.set_source_rgba(0.55, 0.65, 0.75, 0.35)
        for c in self.all_timezones:
            cx = (c["coords"]["x"] / 100.0) * width
            cy = (c["coords"]["y"] / 100.0) * height
            cr.arc(cx, cy, 1.8, 0, 2 * math.pi)
            cr.fill()

        # 3. Seçili Şehrin İşaretçisini Çiz (Pardus / Calamares Radar Stili)
        mx = (self.marker_x_pct / 100.0) * width
        my = (self.marker_y_pct / 100.0) * height

        # Dış Radar Halkası (Glow)
        cr.set_source_rgba(0.22, 0.74, 0.97, 0.25)
        cr.arc(mx, my, 14, 0, 2 * math.pi)
        cr.fill()

        # Hedef Çemberi
        cr.set_source_rgba(0.22, 0.74, 0.97, 0.9)
        cr.set_line_width(1.8)
        cr.arc(mx, my, 8, 0, 2 * math.pi)
        cr.stroke()

        # Merkez Beyaz Nokta
        cr.set_source_rgb(1.0, 1.0, 1.0)
        cr.arc(mx, my, 3.5, 0, 2 * math.pi)
        cr.fill()

        # 4. Pardus TimezoneLabel Eşleniği: Yüzen Bilgi Rozeti
        label_text = f"{self.current_city.replace('_', ' ')}"
        cr.select_font_face("Sans", FONT_NORMAL, FONT_BOLD)
        cr.set_font_size(11)
        ext = cr.text_extents(label_text)

        bx = mx + 12
        by = my - 12
        if bx + ext.width + 16 > width:
            bx = mx - ext.width - 24
        if by - ext.height - 8 < 0:
            by = my + 24

        # Rozet Arka Planı (Koyu cam efekti)
        cr.set_source_rgba(0.06, 0.08, 0.14, 0.90)
        cr.rectangle(bx - 6, by - ext.height - 4, ext.width + 14, ext.height + 10)
        cr.fill()

        # Rozet Kenarlık Çizgisi
        cr.set_source_rgba(0.22, 0.74, 0.97, 0.75)
        cr.set_line_width(1.2)
        cr.rectangle(bx - 6, by - ext.height - 4, ext.width + 14, ext.height + 10)
        cr.stroke()

        # Rozet Metni
        cr.set_source_rgb(0.96, 0.98, 1.0)
        cr.move_to(bx + 1, by + 1)
        cr.show_text(label_text)

    def _on_map_clicked(self, gesture, n_press, x, y):
        w = self.drawing_area.get_width()
        h = self.drawing_area.get_height()
        if w <= 0 or h <= 0 or not self.all_timezones:
            return

        # Tıklanan pikseli Pardus'un 832x425 harita uzayına eşle
        click_orig_x = (x / w) * MAP_SIZE[0]
        click_orig_y = (y / h) * MAP_SIZE[1]

        # Pardus live-installer en yakın şehir formülü:
        # closest_timezone = min(timezones, key=lambda tz: math.sqrt((x - tz.x)**2 + (y - tz.y)**2))
        best_tz = min(
            self.all_timezones,
            key=lambda tz: (click_orig_x - tz["px"]) ** 2 + (click_orig_y - tz["py"]) ** 2
        )

        if best_tz:
            self.set_selected_location(best_tz["region"], best_tz["city"])
            if self.on_city_clicked_callback:
                self.on_city_clicked_callback(best_tz["region"], best_tz)

    def set_selected_location(self, region_name: str, city_name: str):
        self.current_region = region_name
        self.current_city = city_name

        found = False
        if region_name in TIMEZONES:
            for c in TIMEZONES[region_name]:
                if c["city"] == city_name:
                    self.marker_px = c.get("px", 454)
                    self.marker_py = c.get("py", 169)
                    self.marker_x_pct = c["coords"]["x"]
                    self.marker_y_pct = c["coords"]["y"]
                    found = True
                    break

        if not found and self.all_timezones:
            for c in self.all_timezones:
                if c["city"] == city_name:
                    self.marker_px = c.get("px", 454)
                    self.marker_py = c.get("py", 169)
                    self.marker_x_pct = c["coords"]["x"]
                    self.marker_y_pct = c["coords"]["y"]
                    break

        self.drawing_area.queue_draw()
