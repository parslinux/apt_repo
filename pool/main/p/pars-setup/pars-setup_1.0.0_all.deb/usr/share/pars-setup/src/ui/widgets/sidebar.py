"""
ParsLinux Setup - Navigasyon Sidebar Bileşeni
Kurulum adımlarını ve sol alttaki donanım özet kartını yönetir.
"""

import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw

from src.Config import _


class InstallerSidebar(Gtk.Box):
    def __init__(self, hardware: dict, selected_disk_name: str = "nvme0n1"):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.add_css_class("sidebar-box")
        self.set_size_request(230, -1)
        self.hardware = hardware
        self.step_widgets = []

        self._build_ui(selected_disk_name)

    def _build_ui(self, selected_disk_name: str):
        # Adım Başlıkları ve Sembolik İkonlar
        step_definitions = [
            (_("1. Hoş Geldiniz"), "user-home-symbolic"),
            (_("2. Klavye Düzeni"), "input-keyboard-symbolic"),
            (_("3. Konum ve Saat"), "mark-location-symbolic"),
            (_("4. Disk Bölümleme"), "drive-harddisk-symbolic"),
            (_("5. Kullanıcı Hesabı"), "system-users-symbolic"),
            (_("6. Özet ve Onay"), "checkbox-checked-symbolic"),
            (_("7. Kurulum Yapılıyor"), "system-run-symbolic"),
            (_("8. Tamamlandı"), "emblem-default-symbolic")
        ]

        steps_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        for idx, (title, icon_name) in enumerate(step_definitions):
            row_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            row_box.add_css_class("step-row")

            icon = Gtk.Image.new_from_icon_name(icon_name)
            lbl = Gtk.Label(label=title)
            lbl.set_xalign(0)
            lbl.set_hexpand(True)

            row_box.append(icon)
            row_box.append(lbl)
            steps_box.append(row_box)
            self.step_widgets.append((row_box, icon, lbl))

        self.append(steps_box)

        # Boşluk
        spacer = Gtk.Box()
        spacer.set_vexpand(True)
        self.append(spacer)

        # Alt Donanım Bilgi Rozeti
        hw_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        hw_card.add_css_class("info-card")
        hw_card.set_margin_top(16)

        hw_title = Gtk.Label(label=_("Donanım Uyumu"), xalign=0)
        hw_title.add_css_class("caption-heading")
        hw_card.append(hw_title)

        lbl_mode = Gtk.Label(label=f"• {_('Önyükleme')}: {self.hardware.get('boot_mode', 'UEFI')}", xalign=0)
        lbl_mode.add_css_class("dim-label")
        hw_card.append(lbl_mode)

        ram_text = self.hardware.get("ram", {}).get("total_gb", 8.0)
        lbl_ram = Gtk.Label(label=f"• {_('Bellek')}: {ram_text} GB RAM", xalign=0)
        lbl_ram.add_css_class("dim-label")
        hw_card.append(lbl_ram)

        self.lbl_disk = Gtk.Label(label=f"• {_('Hedef')}: {selected_disk_name}", xalign=0)
        self.lbl_disk.add_css_class("dim-label")
        hw_card.append(self.lbl_disk)

        self.append(hw_card)

    def set_active_step(self, current_step: int):
        """Aktif adımı ve tamamlanan adımları görsel olarak günceller."""
        for idx, (row, icon, lbl) in enumerate(self.step_widgets):
            step_num = idx + 1
            row.remove_css_class("active")
            row.remove_css_class("completed")
            if step_num == current_step:
                row.add_css_class("active")
            elif step_num < current_step:
                row.add_css_class("completed")

    def update_target_disk(self, disk_name: str):
        """Seçilen hedef diski donanım özet kartında günceller."""
        self.lbl_disk.set_text(f"• {_('Hedef')}: {disk_name}")
