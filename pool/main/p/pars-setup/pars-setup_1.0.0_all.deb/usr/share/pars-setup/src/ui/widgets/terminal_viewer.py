"""
ParsLinux Setup - Terminal Log İzleyici Bileşeni
Kurulum sırasında gerçek zamanlı terminal günlüğünü gösterir ve daraltma/genişletme olanağı tanır.
"""

import gi
gi.require_version('Gtk', '4.0')
from gi.repository import Gtk

from src.Config import _


class TerminalViewer(Gtk.Box):
    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.is_expanded = False

        self._build_ui()

    def _build_ui(self):
        # Üst Başlık ve Daralt/Genişlet Butonu
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        
        icon = Gtk.Image.new_from_icon_name("utilities-terminal-symbolic")
        lbl = Gtk.Label(label=_("Kurulum Günlüğü ve Konsol Çıktısı"), xalign=0)
        lbl.add_css_class("heading")
        lbl.set_hexpand(True)

        self.btn_toggle = Gtk.Button(label=_("Ayrıntıları Göster"))
        self.btn_toggle.connect("clicked", self._on_toggle_clicked)

        header.append(icon)
        header.append(lbl)
        header.append(self.btn_toggle)
        self.append(header)

        # ScrolledWindow içinde TextView
        self.scroll = Gtk.ScrolledWindow()
        self.scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.scroll.set_size_request(-1, 140)
        self.scroll.set_visible(False)

        self.text_view = Gtk.TextView()
        self.text_view.set_editable(False)
        self.text_view.set_cursor_visible(False)
        self.text_view.set_monospace(True)
        self.text_view.set_wrap_mode(Gtk.WrapMode.CHAR)
        self.text_view.add_css_class("terminal-view")

        self.buffer = self.text_view.get_buffer()
        self.scroll.set_child(self.text_view)
        self.append(self.scroll)

    def _on_toggle_clicked(self, btn):
        self.is_expanded = not self.is_expanded
        self.scroll.set_visible(self.is_expanded)
        self.btn_toggle.set_label(_("Ayrıntıları Gizle") if self.is_expanded else _("Ayrıntıları Göster"))

    def append_log(self, text: str):
        """Günlüğe yeni satır ekler ve aşağı kaydırır."""
        end_iter = self.buffer.get_end_iter()
        self.buffer.insert(end_iter, text + "\n")
        
        # Otomatik en alta kaydır
        mark = self.buffer.create_mark(None, self.buffer.get_end_iter(), False)
        self.text_view.scroll_to_mark(mark, 0.0, True, 0.0, 1.0)
