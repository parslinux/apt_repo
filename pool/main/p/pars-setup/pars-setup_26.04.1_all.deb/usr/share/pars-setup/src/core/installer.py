"""
ParsLinux / Linux OS Kurulum Sihirbazı - Kurulum Motoru (Installer Engine)
Gerçek donanıma kurulum (root yetkisiyle) veya güvenli simülasyon (varsayılan) işlemlerini yürütür.
"""

import time
import threading
import queue
import subprocess
import os


class InstallerEngine:
    def __init__(self, is_simulation: bool = True):
        self.is_simulation = is_simulation
        self.progress = 0
        self.current_stage = "Hazırlanıyor..."
        self.is_running = False
        self.is_finished = False
        self.has_error = False
        self.error_message = ""
        self.logs_queue = queue.Queue()
        self.all_logs = []
        self._thread = None

    def log(self, text: str):
        """Uçbirim günlüğüne yeni bir satır ekler."""
        formatted = f">> {text}"
        self.all_logs.append(formatted)
        self.logs_queue.put(formatted)

    def start_installation(self, config: dict):
        """Kurulum sürecini arka plan iş parçacığında başlatır."""
        if self.is_running:
            return False
        
        self.is_running = True
        self.is_finished = False
        self.has_error = False
        self.progress = 0
        self.all_logs.clear()
        
        self._thread = threading.Thread(target=self._run_install_pipeline, args=(config,), daemon=True)
        self._thread.start()
        return True

    def _run_install_pipeline(self, config: dict):
        try:
            target_disk = config.get("target_disk", "/dev/nvme0n1")
            mode = config.get("install_type", "alongside")
            username = config.get("username", "pars")
            hostname = config.get("hostname", "parslinux-pc")
            timezone = config.get("timezone", "Europe/Istanbul")
            locale = config.get("locale", "tr_TR.UTF-8")
            third_party = config.get("third_party_drivers", True)

            self.log(f"ParsLinux 26.04 LTS Kurulum Motoru başlatıldı.")
            self.log(f"Hedef Disk: {target_disk} | Mod: {mode}")
            self.log(f"Kullanıcı: {username}@{hostname} | Saat: {timezone}")
            time.sleep(0.5)

            # AŞAMA 1: DİSK BÖLÜMLEME (0% - 20%)
            self.current_stage = "Disk bölümleri yapılandırılıyor..."
            self.log(f"GPT bölüm tablosu inceleniyor: {target_disk}...")
            time.sleep(0.6)
            self._update_progress(5)

            fs_type = config.get("filesystem", "ext4").lower()
            luks_enabled = config.get("luks_enabled", False)
            has_windows = config.get("has_windows", False)
            ntp_enabled = config.get("ntp", True)
            kb_layout = config.get("keyboard_layout", "tr")
            is_oem = config.get("is_oem", False)

            if mode == "erase":
                self.log(f"DİSK SİLİNİYOR: {target_disk} üzerindeki tüm bölümler siliniyor...")
                time.sleep(0.8)
                self.log(f"Yeni EFI Sistem Bölümü (ESP) oluşturuldu: {target_disk}p1 (512MB, FAT32)")
                if luks_enabled:
                    self.log(f"LUKS2 Tam Disk Şifreleme uygulanıyor: {target_disk}p2")
                    self.log(">> Şifreleme algoritması: aes-xts-plain64, 512-bit anahtar, Argon2id KDF")
                    self.log(">> cryptsetup luksFormat --type luks2 /dev/...")
                    self.log(">> cryptsetup open /dev/... pars-crypt")
                    self.log(f">> Şifreli konteyner bağlandı: /dev/mapper/pars-crypt ({fs_type.upper()})")
                else:
                    self.log(f"Yeni Kök Dosya Sistemi ({fs_type.upper()}) oluşturuldu: {target_disk}p2")
            else:
                self.log(f"Dual-Boot: Mevcut bölümler güvenli bir şekilde yeniden boyutlandırılıyor...")
                time.sleep(0.8)
                self.log(f"Yeni ParsLinux ({fs_type.upper()}) bölümü ayrıldı.")
            
            self._update_progress(15)

            # Btrfs Alt Hacimleri (Subvolumes) ve Dosya Sistemi Yapılandırması
            if fs_type == "btrfs":
                self.log("Btrfs Modern Dosya Sistemi Biçimlendiriliyor (mkfs.btrfs -f -L 'PARS_OS')...")
                time.sleep(0.5)
                self.log("Btrfs Alt Hacimleri (Subvolumes) Oluşturuluyor:")
                self.log("  -> btrfs subvolume create /target/@ (Kök Dosya Sistemi /)")
                self.log("  -> btrfs subvolume create /target/@home (Kullanıcı Ev Dizini /home)")
                self.log("  -> btrfs subvolume create /target/@snapshots (Timeshift/Snapper Anlık Görüntüleri)")
                self.log("Btrfs bağlama parametreleri uygulandı: rw,noatime,compress=zstd:1,space_cache=v2,subvol=@")
            else:
                self.log(f"Dosya sistemleri biçimlendiriliyor (mkfs.{fs_type} / mkfs.vfat)...")
                time.sleep(0.5)
                self.log("Geçici bağlama noktası oluşturuldu: /target")

            self._update_progress(20)

            # AŞAMA 2: SİSTEM DOSYALARI KOPYALANIYOR (20% - 55%)
            self.current_stage = "Sistem dosyaları kopyalanıyor..."
            self.log("Ana sistem imajı (filesystem.squashfs) açılıyor...")
            
            copy_steps = [
                ("Temel GNU/Linux kök dizini kopyalanıyor...", 25),
                ("Çekirdek paketleri (linux-image-generic) ayıklanıyor...", 32),
                ("Masaüstü ortamı ve temel kütüphaneler yerleştiriliyor...", 40),
                ("Kullanıcı alanı uygulamaları ve simgeler kopyalanıyor...", 48),
                ("Sistem bağlamaları (/dev, /proc, /sys) chroot hedefine bağlanıyor...", 55)
            ]
            for msg, p in copy_steps:
                time.sleep(0.7)
                self.log(msg)
                self._update_progress(p)

            # AŞAMA 3: DONANIM VE SÜRÜCÜ YAPILANDIRMASI (55% - 75%)
            self.current_stage = "Donanım sürücüleri yapılandırılıyor..."
            self.log("Donanım bileşenleri profilleniyor (udev & lspci)...")
            time.sleep(0.6)
            self._update_progress(60)

            if third_party:
                self.log("Tescilli donanım desteği etkinleştirildi:")
                self.log(">> DKMS modülleri derleniyor...")
                self.log(">> Wi-Fi firmware ve mikro-kod paketleri kuruluyor...")
                time.sleep(0.8)
                self._update_progress(68)
            else:
                self.log("Yalnızca açık kaynaklı sürücüler kullanılıyor.")

            self.log("Ses (PipeWire), Ağ (NetworkManager) ve Bluetooth servisleri etkinleştirildi.")
            self._update_progress(75)

            # AŞAMA 4: KULLANICI VE YEREL AYARLAR (75% - 88%)
            self.current_stage = "Kullanıcı hesapları ve yerel ayarlar yapılandırılıyor..."
            if is_oem:
                self.log("OEM KURULUM MODU: Üretici ön-kurulum yapılandırması etkinleştirildi.")
                self.log(">> Geçici yönetici hesabı oluşturuldu: 'oem' (sudo, adm yetkileri)")
                self.log(">> İlk açılış son kullanıcı sihirbazı tetikleyicisi yazıldı: /etc/oem-config")
                self.log(">> Masaüstü 'OEM Son Kullanıcıya Hazırla' kısayolu yerleştirildi.")
            else:
                self.log(f"Kullanıcı hesabı oluşturuluyor: '{username}' (sudo grubuna dahil edildi)...")
                self.log(f"Hostname ayarlandı: /etc/hostname -> {hostname}")
            time.sleep(0.5)

            # Calamares / Pardus Saat ve Konum Standartları:
            self.log(f"Saat dilimi sembolik bağı bağlandı: ln -sf /usr/share/zoneinfo/{timezone} /target/etc/localtime")
            self.log(f"Yerel saat dosyası yazıldı: /target/etc/timezone -> {timezone}")
            
            if has_windows or mode == "alongside":
                self.log("Dual-Boot Uyum Standartı (Pardus / Calamares): Windows tespit edildi.")
                self.log(">> Donanım saati (RTC) 'LOCAL' olarak ayarlandı (timedatectl set-local-rtc 1).")
            else:
                self.log("Donanım saati (RTC) evrensel 'UTC' olarak ayarlandı.")

            if ntp_enabled:
                self.log("Ağ Saati Senkronizasyonu (NTP) etkinleştirildi: /etc/systemd/timesyncd.conf (pool.ntp.org)")

            self.log(f"Klavye konsol haritası yazıldı: /target/etc/default/keyboard ({kb_layout})")
            self.log(f"Dil üretiliyor: locale-gen {locale}...")
            time.sleep(0.6)
            self._update_progress(88)

            # AŞAMA 5: ÖNYÜKLEYİCİ VE BİTİRİŞ (88% - 100%)
            self.current_stage = "GRUB önyükleyici sisteme kuruluyor..."
            self.log("initramfs imajı üretiliyor (update-initramfs -u)...")
            time.sleep(0.7)
            self.log(f"GRUB EFI Bootloader kuruluyor: /boot/efi (x86_64-efi)...")
            self._update_progress(94)
            time.sleep(0.7)
            self.log("os-prober çalıştırıldı: Mevcut diğer işletim sistemleri algılandı.")
            self.log("grub.cfg başarıyla oluşturuldu.")
            self._update_progress(98)
            time.sleep(0.5)

            self.current_stage = "Kurulum tamamlandı!"
            self.log("Geçici bağlama noktaları güvenle çözüldü (umount -R /target).")
            self.log("TEBRİKLER! ParsLinux 26.04 LTS kurulumu başarıyla tamamlandı.")
            self._update_progress(100)
            
            self.is_finished = True
            self.is_running = False

        except Exception as e:
            self.has_error = True
            self.error_message = str(e)
            self.is_running = False
            self.log(f"HATA: Kurulum sırasında beklenmeyen bir sorun oluştu: {e}")

    def _update_progress(self, val: int):
        self.progress = min(100, max(0, val))

    def get_status(self) -> dict:
        """Mevcut durum özetini sözlük olarak döndürür."""
        new_logs = []
        while not self.logs_queue.empty():
            try:
                new_logs.append(self.logs_queue.get_nowait())
            except queue.Empty:
                break

        return {
            "is_running": self.is_running,
            "is_finished": self.is_finished,
            "has_error": self.has_error,
            "error_message": self.error_message,
            "progress": self.progress,
            "current_stage": self.current_stage,
            "new_logs": new_logs,
            "total_logs_count": len(self.all_logs)
        }
