"""
ParsLinux / Linux OS Kurulum Sihirbazı - Dil, Klavye ve Saat Dilimi Modülü
"""

import subprocess
import os


SUPPORTED_LANGUAGES = [
    {"code": "tr_TR.UTF-8", "name": "Türkçe", "flag": "🇹🇷", "locale": "tr_TR"},
    {"code": "en_US.UTF-8", "name": "English (US)", "flag": "🇺🇸", "locale": "en_US"},
    {"code": "de_DE.UTF-8", "name": "Deutsch", "flag": "🇩🇪", "locale": "de_DE"},
    {"code": "fr_FR.UTF-8", "name": "Français", "flag": "🇫🇷", "locale": "fr_FR"},
    {"code": "es_ES.UTF-8", "name": "Español", "flag": "🇪🇸", "locale": "es_ES"},
    {"code": "it_IT.UTF-8", "name": "Italiano", "flag": "🇮🇹", "locale": "it_IT"},
    {"code": "ru_RU.UTF-8", "name": "Русский", "flag": "🇷🇺", "locale": "ru_RU"},
    {"code": "az_AZ.UTF-8", "name": "Azərbaycanca", "flag": "🇦🇿", "locale": "az_AZ"}
]

KEYBOARD_LAYOUTS = [
    {
        "layout": "tr",
        "name": "Türkçe",
        "variants": [
            {"id": "tr", "name": "Türkçe (Türkçe Q Standart)"},
            {"id": "tr-f", "name": "Türkçe (Türkçe F)"},
            {"id": "tr-alt", "name": "Türkçe (Alt-Q)"},
            {"id": "tr-dvorak", "name": "Türkçe (Dvorak)"}
        ]
    },
    {
        "layout": "us",
        "name": "English (US)",
        "variants": [
            {"id": "us", "name": "English (US - Standart)"},
            {"id": "us-intl", "name": "English (US - International)"},
            {"id": "us-dvorak", "name": "English (Dvorak)"}
        ]
    },
    {
        "layout": "de",
        "name": "Deutsch",
        "variants": [
            {"id": "de", "name": "German (Standard QWERTZ)"},
            {"id": "de-nodeadkeys", "name": "German (No dead keys)"}
        ]
    },
    {
        "layout": "fr",
        "name": "Français",
        "variants": [
            {"id": "fr", "name": "French (AZERTY)"},
            {"id": "fr-bepo", "name": "French (Bépo)"}
        ]
    }
]

import math
import re
from collections import defaultdict
from src.Config import DATA_DIR

# Pardus / Ubiquity Miller Cylindrical Projection Standartları
MAP_CENTER = (388, 272)
MAP_SIZE = (832, 425)


def to_float(position: str, wholedigits: int) -> float:
    """Pardus / Calamares koordinat ayrıştırıcı"""
    assert position and len(position) > 4 and wholedigits < 9
    return float(position[:wholedigits + 1] + '.' + position[wholedigits + 1:])


def pixel_position(lat: float, lon: float) -> tuple:
    """Miller cylindrical projection formülü (Pardus standardı)"""
    dx = MAP_SIZE[0] / 2 / 180
    dy = MAP_SIZE[1] / 2 / 90
    x = MAP_CENTER[0] + dx * lon
    y = MAP_CENTER[1] - dy * math.degrees(
        5 / 4 * math.log(math.tan(math.pi / 4 + 2 / 5 * math.radians(lat)))
    )
    return int(x), int(y)


TZ_SPLIT_COORDS = re.compile(r'([+-][0-9]+)([+-][0-9]+)')


def _load_all_system_timezones():
    """
    Sistemdeki /usr/share/zoneinfo/zone.tab dosyasından tüm saat dilimlerini
    Miller silindirik projeksiyonu ile koordinatlandırarak yükler.
    """
    zones = defaultdict(list)
    zone_tab = '/usr/share/zoneinfo/zone.tab'
    if not os.path.exists(zone_tab):
        zone_tab = '/usr/share/zoneinfo/zone1970.tab'

    if os.path.exists(zone_tab):
        try:
            with open(zone_tab, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    parts = line.split(None, 2)
                    if len(parts) < 3:
                        continue
                    ccode, coords, name = parts[0], parts[1], parts[2].split()[0]
                    m = TZ_SPLIT_COORDS.search(coords)
                    if not m:
                        continue
                    lat_str, lon_str = m.groups()
                    lat = to_float(lat_str, 2)
                    lon = to_float(lon_str, 3)
                    x, y = pixel_position(lat, lon)
                    if x < 0:
                        x = MAP_SIZE[0] + x

                    parts_name = name.split('/')
                    region = parts_name[0]
                    city = '/'.join(parts_name[1:])
                    clean_label = city.replace('_', ' ')

                    entry = {
                        'city': city,
                        'region': region,
                        'label': clean_label,
                        'timezone': name,
                        'ccode': ccode,
                        'px': x,
                        'py': y,
                        'coords': {
                            'x': (x / MAP_SIZE[0]) * 100.0,
                            'y': (y / MAP_SIZE[1]) * 100.0
                        }
                    }
                    zones[region].append(entry)
        except Exception:
            pass

    # Eğer sistemde zone.tab okunamazsa yedek liste
    if not zones:
        fallback_cities = [
            ("Europe", "Istanbul", "İstanbul", 454, 169),
            ("Europe", "Berlin", "Berlin", 418, 135),
            ("Europe", "London", "Londra", 399, 132),
            ("Europe", "Paris", "Paris", 407, 140),
            ("Asia", "Baku", "Bakü", 498, 172),
            ("Asia", "Tokyo", "Tokyo", 715, 185),
            ("America", "New_York", "New York", 216, 171),
            ("America", "Los_Angeles", "Los Angeles", 133, 185),
            ("Africa", "Cairo", "Kahire", 450, 203),
            ("Australia", "Sydney", "Sidney", 717, 331)
        ]
        for reg, city, lbl, px, py in fallback_cities:
            entry = {
                'city': city,
                'region': reg,
                'label': lbl,
                'timezone': f"{reg}/{city}",
                'ccode': "",
                'px': px,
                'py': py,
                'coords': {
                    'x': (px / MAP_SIZE[0]) * 100.0,
                    'y': (py / MAP_SIZE[1]) * 100.0
                }
            }
            zones[reg].append(entry)

    res = {}
    preferred_order = ['Europe', 'Asia', 'America', 'Africa', 'Australia', 'Atlantic', 'Pacific', 'Indian', 'Antarctica', 'Arctic']
    for r in preferred_order:
        if r in zones:
            res[r] = sorted(zones[r], key=lambda c: c['label'])
    for r, clist in zones.items():
        if r not in res:
            res[r] = sorted(clist, key=lambda c: c['label'])
    return res


TIMEZONES = _load_all_system_timezones()



def apply_live_keyboard(layout: str, variant: str = ""):
    """Canlı oturumda klavye yerleşimini anında değiştirir (setxkbmap)."""
    try:
        cmd = ["setxkbmap", layout]
        if variant and variant != layout:
            cmd.extend(["-variant", variant])
        subprocess.run(cmd, capture_output=True, timeout=2)
        return True
    except Exception:
        return False


def detect_geoip_timezone() -> dict:
    """
    İnternet bağlantısı varsa GeoIP üzerinden kullanıcının yaklaşık konumunu ve saat dilimini tespit eder.
    (Pardus / Calamares / Ubuntu standardı).
    """
    import urllib.request
    import json
    try:
        req = urllib.request.Request(
            "http://ip-api.com/json/?fields=status,country,city,timezone,lat,lon",
            headers={"User-Agent": "ParsLinux-Installer/26.04"}
        )
        with urllib.request.urlopen(req, timeout=1.8) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            if data.get("status") == "success":
                tz = data.get("timezone", "")
                parts = tz.split("/")
                if len(parts) == 2:
                    return {
                        "success": True,
                        "region": parts[0],
                        "city": parts[1],
                        "country": data.get("country", ""),
                        "timezone": tz,
                        "lat": data.get("lat"),
                        "lon": data.get("lon")
                    }
    except Exception:
        pass
    return {"success": False, "region": "Europe", "city": "Istanbul", "timezone": "Europe/Istanbul"}

