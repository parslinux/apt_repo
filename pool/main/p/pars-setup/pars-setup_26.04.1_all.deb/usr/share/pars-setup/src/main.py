#!/usr/bin/env python3
"""
ParsLinux 26.04 LTS Kurulum Sihirbazı (GTK4 & Libadwaita)
Uygulama Giriş Noktası (Application Entry Point)
"""

import sys
import os

# src dizinini ve kök dizini sys.path'e ekle
SRC_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(SRC_DIR)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Adw, Gio

from src.Config import APP_ID, APP_NAME
from src.ui.window import InstallerWindow


class ParsSetupApp(Adw.Application):
    def __init__(self, is_oem: bool = False):
        super().__init__(
            application_id=APP_ID,
            flags=Gio.ApplicationFlags.FLAGS_NONE
        )
        self.is_oem = is_oem
        self.set_resource_base_path(f"/{APP_ID.replace('.', '/')}")

    def do_activate(self):
        # Koyu tema şemasını zorla (Kurulum ortamı ve OS deneyimi için tutarlı koyu palet)
        style_manager = Adw.StyleManager.get_default()
        style_manager.set_color_scheme(Adw.ColorScheme.FORCE_DARK)

        win = self.props.active_window
        if not win:
            win = InstallerWindow(is_oem=self.is_oem, application=self)
        win.present()


def main():
    is_oem = "--oem" in sys.argv
    clean_args = [a for a in sys.argv if a != "--oem"]
    app = ParsSetupApp(is_oem=is_oem)
    return app.run(clean_args)


if __name__ == "__main__":
    sys.exit(main())
