"""
ParsLinux Setup - 7. Adım: Kurulum İlerlemesi Sayfası
Otomatik rotasyonlu slaytlar, gezinme noktaları, log dışa aktarma ve canlı terminal konsolu.
"""

import os
import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw, GLib

from src.Config import _
from src.ui.widgets.terminal_viewer import TerminalViewer


class PageProgress(Gtk.ScrolledWindow):
    def __init__(self):
        super().__init__()
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)

        self.slides = [
            (_("ParsLinux Dünyasına Hoş Geldiniz"), _("Modern Libadwaita arayüzü, kararlı Linux çekirdeği ve akıcı masaüstü deneyimi."), "distributor-logo"),
            (_("Üstün Güvenlik ve Gizlilik"), _("Arka planda telemetri veya izinsiz veri toplama yok. Güvenlik ve gizlilik sizin kontrolünüzde."), "security-high-symbolic"),
            (_("Steam ve Proton ile Oyun"), _("Vulkan optimizasyonları ve Proton desteğiyle binlerce Windows ve yerel Linux oyunu hazır."), "input-gaming-symbolic"),
            (_("Flathub ve Zengin Yazılım Deposu"), _("VS Code, Blender, Discord, OBS Studio ve geliştirme ortamları tek tıkla elinizin altında."), "system-software-install-symbolic")
        ]
        self.current_slide_idx = 0
        self.collected_logs = []
        self._slide_timer_id = None

        self._build_ui()

    def _build_ui(self):
        clamp = Adw.Clamp()
        clamp.set_maximum_size(740)
        clamp.set_tightening_threshold(560)

        page_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        page_box.add_css_class("content-box")
        clamp.set_child(page_box)
        self.set_child(clamp)

        # Slayt Kartı (Özellik Tanıtımı)
        self.slide_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.slide_card.add_css_class("info-card")
        self.slide_card.set_valign(Gtk.Align.CENTER)

        self.slide_icon = Gtk.Image.new_from_icon_name("distributor-logo")
        self.slide_icon.set_pixel_size(48)
        
        self.slide_title = Gtk.Label(label=self.slides[0][0])
        self.slide_title.add_css_class("title-2")

        self.slide_desc = Gtk.Label(label=self.slides[0][1], wrap=True)
        self.slide_desc.add_css_class("dim-label")

        # Slayt Navigasyon Noktaları (Dots)
        self.dots_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self.dots_box.set_halign(Gtk.Align.CENTER)
        self.dot_widgets = []
        for i in range(len(self.slides)):
            dot = Gtk.Box()
            dot.set_size_request(8, 8)
            dot.add_css_class("legend-dot-pars" if i == 0 else "legend-dot-existing")
            self.dots_box.append(dot)
            self.dot_widgets.append(dot)

        self.slide_card.append(self.slide_icon)
        self.slide_card.append(self.slide_title)
        self.slide_card.append(self.slide_desc)
        self.slide_card.append(self.dots_box)
        page_box.append(self.slide_card)

        # Hata Bildirim Kartı (Gizli başlar)
        self.error_card = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        self.error_card.add_css_class("warning-card")
        self.error_card.set_visible(False)
        e_icon = Gtk.Image.new_from_icon_name("dialog-error-symbolic")
        self.lbl_error = Gtk.Label(label="", wrap=True, xalign=0)
        self.error_card.append(e_icon)
        self.error_card.append(self.lbl_error)
        page_box.append(self.error_card)

        # İlerleme Bilgi Başlığı (Aşama Adı ve Yüzde)
        status_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        self.lbl_stage = Gtk.Label(label=_("Kurulum başlatılıyor..."), xalign=0)
        self.lbl_stage.add_css_class("heading")

        self.lbl_percent = Gtk.Label(label="%0", xalign=1)
        self.lbl_percent.set_hexpand(True)
        self.lbl_percent.add_css_class("heading")

        status_box.append(self.lbl_stage)
        status_box.append(self.lbl_percent)
        page_box.append(status_box)

        # İlerleme Çubuğu
        self.progress_bar = Gtk.ProgressBar()
        self.progress_bar.set_fraction(0.0)
        page_box.append(self.progress_bar)

        # Logları Dışa Aktar Butonu
        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.btn_export_logs = Gtk.Button(label=_("Günlüğü Dışa Aktar (Kaydet)"))
        self.btn_export_logs.connect("clicked", self._on_export_logs_clicked)
        btn_box.append(self.btn_export_logs)
        page_box.append(btn_box)

        # Terminal Log Konsolu (Açılır/Kapanır)
        self.terminal_viewer = TerminalViewer()
        page_box.append(self.terminal_viewer)

    def start_slide_timer(self):
        """Her 7 saniyede bir slaytları otomatik döndürür."""
        if not self._slide_timer_id:
            self._slide_timer_id = GLib.timeout_add_seconds(7, self._on_slide_tick)

    def _on_slide_tick(self):
        self.current_slide_idx = (self.current_slide_idx + 1) % len(self.slides)
        self._update_slide_display()
        return True

    def _update_slide_display(self):
        title, desc, icon_name = self.slides[self.current_slide_idx]
        self.slide_title.set_text(title)
        self.slide_desc.set_text(desc)
        self.slide_icon.set_from_icon_name(icon_name)

        for i, dot in enumerate(self.dot_widgets):
            dot.remove_css_class("legend-dot-pars")
            dot.remove_css_class("legend-dot-existing")
            dot.add_css_class("legend-dot-pars" if i == self.current_slide_idx else "legend-dot-existing")

    def update_progress(self, percent: int, stage_text: str, new_logs: list):
        self.progress_bar.set_fraction(percent / 100.0)
        self.lbl_percent.set_text(f"%{percent}")
        self.lbl_stage.set_text(stage_text)

        for line in new_logs:
            self.collected_logs.append(line)
            self.terminal_viewer.append_log(line)

    def show_error(self, message: str):
        self.lbl_error.set_text(message)
        self.error_card.set_visible(True)

    def _on_export_logs_clicked(self, btn):
        log_text = "\n".join(self.collected_logs)
        export_path = os.path.expanduser("~/pars-install.log")
        try:
            with open(export_path, "w", encoding="utf-8") as f:
                f.write(log_text)
            btn.set_label(_("Günlük Kaydedildi: ~/pars-install.log"))
        except Exception as e:
            btn.set_label(_("Kaydedilemedi: ") + str(e))
