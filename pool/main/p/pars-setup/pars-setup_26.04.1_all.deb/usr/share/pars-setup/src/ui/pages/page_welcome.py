"""
ParsLinux Setup - 1. Adım: Hoş Geldiniz Sayfası
Sistem donanım uyumluluk denetimi, çalışma modu (Dene vs Kur), kurulum dili ve tescilli sürücü seçimi.
"""

import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw

from src.Config import _
from src.core.locales import SUPPORTED_LANGUAGES


class PageWelcome(Gtk.ScrolledWindow):
    def __init__(self, hardware: dict, on_try_mode_callback=None):
        super().__init__()
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.hardware = hardware
        self.on_try_mode_callback = on_try_mode_callback

        self._build_ui()

    def _build_ui(self):
        clamp = Adw.Clamp()
        clamp.set_maximum_size(740)
        clamp.set_tightening_threshold(560)

        page_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)
        page_box.add_css_class("content-box")
        clamp.set_child(page_box)
        self.set_child(clamp)

        # Üst Başlık Banner
        title_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
        
        icon = Gtk.Image.new_from_icon_name("distributor-logo")
        icon.set_pixel_size(54)
        
        text_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        h1 = Gtk.Label(label=_("ParsLinux'a Hoş Geldiniz"), xalign=0)
        h1.add_css_class("title-1")
        sub = Gtk.Label(
            label=_("Özgür, modern ve yüksek performanslı işletim sistemi deneyimine başlamak üzeresiniz."),
            wrap=True,
            xalign=0
        )
        sub.add_css_class("dim-label")

        text_vbox.append(h1)
        text_vbox.append(sub)
        title_box.append(icon)
        title_box.append(text_vbox)
        page_box.append(title_box)

        # Çalışma Modu Seçimi: "Dene" vs "Kur" (Ubuntu & Calamares Standardı)
        mode_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=14)
        
        # Seçenek 1: Doğrudan Kur
        self.card_install = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.card_install.add_css_class("disk-option-card")
        self.card_install.add_css_class("selected")
        self.card_install.set_hexpand(True)

        ins_icon = Gtk.Image.new_from_icon_name("drive-harddisk-symbolic")
        ins_icon.set_pixel_size(28)
        lbl_ins = Gtk.Label(label=_("ParsLinux'u Kur"), xalign=0.5)
        lbl_ins.add_css_class("heading")
        lbl_ins_desc = Gtk.Label(label=_("Bilgisayarınıza kalıcı olarak kurun"), xalign=0.5)
        lbl_ins_desc.add_css_class("dim-label")

        self.card_install.append(ins_icon)
        self.card_install.append(lbl_ins)
        self.card_install.append(lbl_ins_desc)

        # Seçenek 2: Canlı Dene
        self.card_try = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.card_try.add_css_class("disk-option-card")
        self.card_try.set_hexpand(True)

        try_icon = Gtk.Image.new_from_icon_name("media-flash-symbolic")
        try_icon.set_pixel_size(28)
        lbl_try = Gtk.Label(label=_("Canlı Ortamda Dene"), xalign=0.5)
        lbl_try.add_css_class("heading")
        lbl_try_desc = Gtk.Label(label=_("Diskinize dokunmadan inceleyin"), xalign=0.5)
        lbl_try_desc.add_css_class("dim-label")

        self.card_try.append(try_icon)
        self.card_try.append(lbl_try)
        self.card_try.append(lbl_try_desc)

        # Tıklama olayları
        try_click = Gtk.GestureClick()
        try_click.connect("released", self._on_try_clicked)
        self.card_try.add_controller(try_click)

        ins_click = Gtk.GestureClick()
        ins_click.connect("released", self._on_install_clicked)
        self.card_install.add_controller(ins_click)

        mode_box.append(self.card_install)
        mode_box.append(self.card_try)
        page_box.append(mode_box)

        # Sistem Donanım Denetimi Kartı (Adw.PreferencesGroup)
        hw_group = Adw.PreferencesGroup()
        hw_group.set_title(_("Sistem ve Donanım Uyumluluk Durumu"))
        hw_group.set_description(_("Minimum gereksinimler denetleniyor (En az 2 GB RAM, 25 GB Disk)"))

        # RAM
        ram_gb = self.hardware.get("ram", {}).get("total_gb", 4.0)
        ram_ok = ram_gb >= 2.0
        row_ram = Adw.ActionRow(title=_("Bellek (RAM)"), subtitle=self.hardware.get("ram", {}).get("text", "4 GB"))
        row_ram.add_prefix(Gtk.Image.new_from_icon_name("memory-symbolic"))
        row_ram.add_suffix(Gtk.Image.new_from_icon_name("emblem-ok-symbolic" if ram_ok else "dialog-warning-symbolic"))
        hw_group.add(row_ram)

        # Önyükleme Modu
        row_boot = Adw.ActionRow(title=_("Önyükleme Modu"), subtitle=self.hardware.get("boot_mode", "UEFI"))
        row_boot.add_prefix(Gtk.Image.new_from_icon_name("computer-symbolic"))
        row_boot.add_suffix(Gtk.Image.new_from_icon_name("emblem-ok-symbolic"))
        hw_group.add(row_boot)

        # Güç / Batarya
        batt = self.hardware.get("battery", {})
        batt_ok = not batt.get("has_battery") or batt.get("charging") or batt.get("percentage", 100) > 30
        row_power = Adw.ActionRow(title=_("Güç Durumu"), subtitle=batt.get("status", "Şebeke"))
        row_power.add_prefix(Gtk.Image.new_from_icon_name("battery-level-100-symbolic"))
        row_power.add_suffix(Gtk.Image.new_from_icon_name("emblem-ok-symbolic" if batt_ok else "dialog-warning-symbolic"))
        hw_group.add(row_power)

        # İnternet
        net_info = self.hardware.get("network", {})
        is_online = net_info.get("online", True)
        row_net = Adw.ActionRow(title=_("İnternet Bağlantısı"), subtitle=net_info.get("status", "Çevrimiçi"))
        row_net.add_prefix(Gtk.Image.new_from_icon_name("network-wireless-symbolic" if is_online else "network-offline-symbolic"))
        row_net.add_suffix(Gtk.Image.new_from_icon_name("emblem-ok-symbolic" if is_online else "dialog-warning-symbolic"))
        hw_group.add(row_net)

        page_box.append(hw_group)

        # Dil Seçimi Grubu
        lang_group = Adw.PreferencesGroup()
        lang_group.set_title(_("Kurulum Tercihleri"))

        lang_row = Adw.ActionRow(title=_("Kurulum Dili"), subtitle=_("Sihirbaz ve kurulacak sistem dili"))
        lang_row.add_prefix(Gtk.Image.new_from_icon_name("preferences-desktop-locale-symbolic"))
        
        self.lang_names = [f"{l['flag']}  {l['name']}" for l in SUPPORTED_LANGUAGES]
        self.drop_lang = Gtk.DropDown.new_from_strings(self.lang_names)
        self.drop_lang.set_selected(0)
        self.drop_lang.set_valign(Gtk.Align.CENTER)
        lang_row.add_suffix(self.drop_lang)
        lang_group.add(lang_row)

        page_box.append(lang_group)

        # Tescilli Sürücüler Kartı
        driver_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        driver_card.add_css_class("info-card")
        
        self.chk_drivers = Gtk.CheckButton.new_with_label(
            _("NVIDIA, Wi-Fi ve ek donanımlar için tescilli (üçüncü taraf) sürücüleri otomatik kur")
        )
        self.chk_drivers.set_active(True)
        driver_card.append(self.chk_drivers)

        note_lbl = Gtk.Label(
            label=_("Öneri: En iyi grafik performansı ve kablosuz bağlantı için işaretli bırakmanız tavsiye edilir."),
            xalign=0,
            wrap=True
        )
        note_lbl.add_css_class("dim-label")
        driver_card.append(note_lbl)
        page_box.append(driver_card)

        # Alt Bağlantılar (Sürüm Notları & Web)
        links_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
        links_box.set_halign(Gtk.Align.CENTER)

        btn_notes = Gtk.LinkButton.new_with_label("https://parslinux.org/releases/26.04", _("Sürüm Notlarını Oku"))
        btn_help = Gtk.LinkButton.new_with_label("https://parslinux.org/docs", _("Topluluk Yardımı ve Belgeler"))
        links_box.append(btn_notes)
        links_box.append(btn_help)
        page_box.append(links_box)

    def _on_try_clicked(self, gesture, n_press, x, y):
        self.card_try.add_css_class("selected")
        self.card_install.remove_css_class("selected")
        if self.on_try_mode_callback:
            self.on_try_mode_callback()

    def _on_install_clicked(self, gesture, n_press, x, y):
        self.card_install.add_css_class("selected")
        self.card_try.remove_css_class("selected")

    def get_selected_language(self) -> dict:
        idx = self.drop_lang.get_selected()
        if idx < len(SUPPORTED_LANGUAGES):
            return SUPPORTED_LANGUAGES[idx]
        return SUPPORTED_LANGUAGES[0]

    def get_install_third_party(self) -> bool:
        return self.chk_drivers.get_active()
