"""
ParsLinux Setup - Ana Pencere (Adw.ApplicationWindow)
GNOME/Libadwaita standartlarında 8 adımlı kurulum sihirbazını koordine eder.
"""

import os
import sys
import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw, GLib, Gio, Gdk

from src.Config import APP_NAME, VERSION, DATA_DIR, IS_SIMULATION, _
from src.core.hardware import get_full_hardware_summary
from src.core.disks import get_block_devices
from src.core.installer import InstallerEngine

from src.ui.widgets.sidebar import InstallerSidebar
from src.ui.pages.page_welcome import PageWelcome
from src.ui.pages.page_keyboard import PageKeyboard
from src.ui.pages.page_timezone import PageTimezone
from src.ui.pages.page_disk import PageDisk
from src.ui.pages.page_users import PageUsers
from src.ui.pages.page_summary import PageSummary
from src.ui.pages.page_progress import PageProgress
from src.ui.pages.page_finish import PageFinish


class InstallerWindow(Adw.ApplicationWindow):
    def __init__(self, is_oem: bool = False, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.is_oem = is_oem

        self.set_title(f"{APP_NAME} v{VERSION}")
        self.set_default_size(980, 680)
        self.set_size_request(860, 580)

        # GNOME / Libadwaita Koyu Tema Zorunluluğu
        style_manager = Adw.StyleManager.get_default()
        style_manager.set_color_scheme(Adw.ColorScheme.FORCE_DARK)

        # Durum ve Donanım
        self.current_step = 1
        self.total_steps = 8
        self.hardware = get_full_hardware_summary()
        self.disks = get_block_devices()
        self.engine = InstallerEngine(is_simulation=IS_SIMULATION)

        self._load_css()
        self._build_ui()
        self._update_step_ui()

    def _load_css(self):
        css_path = os.path.join(DATA_DIR, "style.css")
        if os.path.exists(css_path):
            provider = Gtk.CssProvider()
            provider.load_from_path(css_path)
            Gtk.StyleContext.add_provider_for_display(
                Gdk.Display.get_default(),
                provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )

    def _build_ui(self):
        # Ana Dikey Kutu
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.set_content(main_box)

        # 1. Libadwaita HeaderBar
        header_bar = Adw.HeaderBar()
        title_widget = Adw.WindowTitle(
            title="ParsLinux 26.04 LTS",
            subtitle=_("İşletim Sistemi Kurulum Sihirbazı")
        )
        header_bar.set_title_widget(title_widget)

        # Donanım Durum Rozeti (HeaderBar sağına)
        boot_mode = self.hardware.get("boot_mode", "UEFI")
        ram_gb = self.hardware.get("ram", {}).get("total_gb", 8.0)
        hw_chip = Gtk.Label(label=f"{boot_mode} • {ram_gb} GB RAM")
        hw_chip.add_css_class("dim-label")
        hw_chip.set_margin_end(12)
        header_bar.pack_end(hw_chip)

        if IS_SIMULATION:
            sim_badge = Gtk.Label(label=_("🧪 Simülasyon (Güvenli)"))
            sim_badge.add_css_class("badge-simulation")
            sim_badge.set_tooltip_text(_("Disklerinize dokunulmaz. Tüm kurulum güvenle test edilir."))
            sim_badge.set_margin_end(8)
            header_bar.pack_end(sim_badge)

        main_box.append(header_bar)

        # 2. Orta Bölge (Sidebar + Sayfa Stack'i)
        center_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        center_box.set_vexpand(True)
        main_box.append(center_box)

        # Sol Sidebar
        first_disk_name = self.disks[0]["name"] if self.disks else "nvme0n1"
        self.sidebar = InstallerSidebar(self.hardware, selected_disk_name=first_disk_name)
        center_box.append(self.sidebar)

        # Sağ Alan: Gtk.Stack ile Sayfalar
        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT_RIGHT)
        self.stack.set_transition_duration(240)
        self.stack.set_hexpand(True)
        self.stack.set_vexpand(True)
        center_box.append(self.stack)

        # Sayfaları Başlat
        self.page1 = PageWelcome(self.hardware, on_try_mode_callback=self._on_try_mode)
        self.page2 = PageKeyboard()
        self.page3 = PageTimezone()
        self.page4 = PageDisk(
            self.disks,
            on_disk_changed_callback=self._on_disk_changed,
            on_validation_changed_callback=self._check_step_validation
        )
        self.page5 = PageUsers(on_validation_changed_callback=self._check_step_validation, is_oem_default=self.is_oem)
        self.page6 = PageSummary(on_jump_step_callback=self._goto_step)
        self.page7 = PageProgress()
        self.page8 = PageFinish(on_stay_in_live_callback=self.close)

        self.stack.add_named(self.page1, "step1")
        self.stack.add_named(self.page2, "step2")
        self.stack.add_named(self.page3, "step3")
        self.stack.add_named(self.page4, "step4")
        self.stack.add_named(self.page5, "step5")
        self.stack.add_named(self.page6, "step6")
        self.stack.add_named(self.page7, "step7")
        self.stack.add_named(self.page8, "step8")

        # 3. Alt Eylem Çubuğu
        action_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        action_bar.set_margin_top(8)
        action_bar.set_margin_bottom(12)
        action_bar.set_margin_start(16)
        action_bar.set_margin_end(16)
        main_box.append(action_bar)

        self.btn_cancel = Gtk.Button(label=_("Vazgeç"))
        self.btn_cancel.connect("clicked", self._on_cancel_clicked)
        action_bar.append(self.btn_cancel)

        spacer = Gtk.Box()
        spacer.set_hexpand(True)
        action_bar.append(spacer)

        self.btn_prev = Gtk.Button(label=f"< {_('Geri')}")
        self.btn_prev.connect("clicked", self._on_prev_clicked)
        action_bar.append(self.btn_prev)

        self.btn_next = Gtk.Button(label=f"{_('İleri')} >")
        self.btn_next.add_css_class("suggested-btn")
        self.btn_next.connect("clicked", self._on_next_clicked)
        action_bar.append(self.btn_next)

    def _on_try_mode(self):
        print("[*] Canlı oturum seçildi. Kurulum sihirbazı kapatılıyor...")
        self.close()

    def _on_disk_changed(self, disk: dict):
        self.sidebar.update_target_disk(disk.get("name", "nvme0n1"))

    def _compile_full_config(self) -> dict:
        return {
            "language": self.page1.get_selected_language(),
            "third_party_drivers": self.page1.get_install_third_party(),
            "keyboard": self.page2.get_selected_keyboard(),
            "timezone": self.page3.get_selected_timezone(),
            "disk": self.page4.get_disk_config(),
            "user": self.page5.get_user_config()
        }

    def _check_step_validation(self):
        """Mevcut adımdaki girdi geçerliliğini denetleyerek İleri butonunu kilitler/açar."""
        if self.current_step == 5:
            is_valid = self.page5.is_valid()
            self.btn_next.set_sensitive(is_valid)
        elif self.current_step == 4:
            is_valid = self.page4.is_valid()
            self.btn_next.set_sensitive(is_valid)
        elif self.current_step in [1, 2, 3]:
            self.btn_next.set_sensitive(True)

    def _update_step_ui(self):
        self.stack.set_visible_child_name(f"step{self.current_step}")
        self.sidebar.set_active_step(self.current_step)

        # Buton durumları
        self.btn_prev.set_sensitive(self.current_step not in [1, 7, 8])
        self.btn_cancel.set_sensitive(self.current_step not in [7, 8])

        if self.current_step == 6:
            full_config = self._compile_full_config()
            self.page6.update_summary(full_config)
            self.btn_next.set_sensitive(True)
            self.btn_next.set_label(_("Şimdi Kur"))
            self.btn_next.remove_css_class("suggested-btn")
            self.btn_next.add_css_class("install-now-btn")
        elif self.current_step == 7:
            self.btn_next.set_sensitive(False)
            self.page7.start_slide_timer()
            self._start_installation()
        elif self.current_step == 8:
            self.btn_prev.set_visible(False)
            self.btn_cancel.set_visible(False)
            self.btn_next.set_sensitive(True)
            self.btn_next.set_label(_("Bitir ve Yeniden Başlat"))
            self.btn_next.remove_css_class("suggested-btn")
            self.btn_next.add_css_class("install-now-btn")
        else:
            self.btn_next.set_label(f"{_('İleri')} >")
            self.btn_next.remove_css_class("install-now-btn")
            self.btn_next.add_css_class("suggested-btn")
            self._check_step_validation()

    def _goto_step(self, step_number: int):
        if 1 <= step_number <= self.total_steps:
            self.current_step = step_number
            self._update_step_ui()

    def _on_next_clicked(self, btn):
        if self.current_step == 8:
            if self.page8.is_restart_requested():
                if not IS_SIMULATION:
                    os.system("systemctl reboot &")
                else:
                    print("[*] Simülasyon modu tamamlandı. Sistem yeniden başlatma komutu tetiklendi.")
            self.close()
            return

        if self.current_step < self.total_steps:
            self.current_step += 1
            self._update_step_ui()

    def _on_prev_clicked(self, btn):
        if self.current_step > 1:
            self.current_step -= 1
            self._update_step_ui()

    def _on_cancel_clicked(self, btn):
        dialog = Adw.MessageDialog.new(
            self,
            _("Kurulumdan Çıkılsın mı?"),
            _("Sihirbazı kapatırsanız kurulum tamamlanmayacak ve mevcut canlı masaüstünde kalacaksınız.")
        )
        dialog.add_response("cancel", _("Devam Et"))
        dialog.add_response("exit", _("Çıkış Yap"))
        dialog.set_response_appearance("exit", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.set_default_response("cancel")

        def on_response(dlg, response_id):
            if response_id == "exit":
                self.close()

        dialog.connect("response", on_response)
        dialog.present()

    def _start_installation(self):
        full_cfg = self._compile_full_config()
        cfg_for_engine = {
            "target_disk": full_cfg["disk"]["disk_path"],
            "install_type": full_cfg["disk"]["mode"],
            "filesystem": full_cfg["disk"]["filesystem"],
            "swap_type": full_cfg["disk"]["swap_type"],
            "luks_enabled": full_cfg["disk"]["luks_enabled"],
            "has_windows": full_cfg["disk"].get("disk", {}).get("has_windows", False) if full_cfg["disk"].get("disk") else False,
            "ntp": full_cfg["timezone"].get("ntp", True),
            "keyboard_layout": full_cfg["keyboard"].get("layout", "tr"),
            "username": full_cfg["user"]["username"],
            "hostname": full_cfg["user"]["hostname"],
            "is_oem": full_cfg["user"].get("is_oem", False),
            "timezone": full_cfg["timezone"]["timezone_str"],
            "locale": full_cfg["language"]["code"],
            "third_party_drivers": full_cfg["third_party_drivers"]
        }
        self.engine.start_installation(cfg_for_engine)
        GLib.timeout_add(150, self._poll_installation)

    def _poll_installation(self):
        status = self.engine.get_status()
        self.page7.update_progress(
            status["progress"],
            status["current_stage"],
            status["new_logs"]
        )

        if status.get("has_error"):
            self.page7.show_error(status.get("error_message", "Bilinmeyen kurulum hatası"))
            return False

        if status["is_finished"]:
            GLib.timeout_add(700, self._finish_installation)
            return False
        return True

    def _finish_installation(self):
        self.current_step = 8
        self._update_step_ui()
        return False
