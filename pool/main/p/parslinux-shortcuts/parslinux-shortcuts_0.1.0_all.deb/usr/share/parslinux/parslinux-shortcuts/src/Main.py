#!/usr/bin/env python3
import sys
import gi

gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw, Gio, GLib


class Application(Adw.Application):

    def __init__(self, **kwargs):
        super().__init__(
            **kwargs,
            application_id="org.parslinux.shortcuts",
            flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE
        )
        self.main_window = None
        self.greeter_mode = False
        self.initial_category = None

        self.add_main_option(
            "greeter",
            ord("g"),
            GLib.OptionFlags.NONE,
            GLib.OptionArg.NONE,
            "Run in Greeter embedded/companion mode",
            None
        )
        self.add_main_option(
            "category",
            ord("c"),
            GLib.OptionFlags.NONE,
            GLib.OptionArg.STRING,
            "Directly filter by category name",
            "CATEGORY"
        )

    def do_command_line(self, command_line):
        options = command_line.get_options_dict()
        if options.contains("greeter"):
            self.greeter_mode = True
        if options.contains("category"):
            self.initial_category = options.lookup_value("category").get_string()
        self.activate()
        return 0

    def do_activate(self):
        if not self.main_window:
            from MainWindow import MainWindow
            self.main_window = MainWindow(
                application=self,
                greeter_mode=self.greeter_mode,
                initial_category=self.initial_category
            )
        self.main_window.present()


if __name__ == "__main__":
    app = Application()
    app.run(sys.argv)
