import gi
import os
import json
import shutil
import subprocess

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")

from gi.repository import Gtk, Gdk, Gio, Adw, GLib, GObject

try:
    import locale
    from locale import gettext as _

    APPNAME = "parslinux-shortcuts"
    TRANSLATION_PATH = "/usr/share/locale"

    locale.bindtextdomain(APPNAME, TRANSLATION_PATH)
    locale.textdomain(APPNAME)
except Exception:
    def _(msg):
        return msg


class MainWindow(Adw.ApplicationWindow):
    def __init__(self, greeter_mode=False, initial_category=None, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.greeter_mode = greeter_mode
        self.initial_category = initial_category
        self.search_query = ""

        # Paths
        self.script_dir = os.path.dirname(os.path.realpath(__file__))
        self.data_dir = os.path.join(self.script_dir, "../data")

        # Desktop Environment Detection
        self.desktop_env = self.detect_desktop_environment()

        # Load Data
        self.datas = {}
        self.custom_shortcuts = []
        self.shortcuts = []
        self.load_data()

        # Window Setup
        self.set_title(_("Pars Linux Shortcuts"))
        self.set_default_size(1020, 700)

        # Keyboard shortcuts (Esc to close in greeter mode, Ctrl+F for search)
        key_controller = Gtk.EventControllerKey()
        key_controller.connect("key-pressed", self.on_key_pressed)
        self.add_controller(key_controller)

        # Default Mode: "grid" or "list"
        self.current_mode = "grid"
        self.search_active = False

        # Toast Overlay for in-app notifications
        self.toast_overlay = Adw.ToastOverlay()

        self.update_ui()

    def detect_desktop_environment(self):
        desktop = os.environ.get("XDG_CURRENT_DESKTOP", "").lower()
        if "gnome" in desktop:
            return "gnome"
        elif "xfce" in desktop:
            return "xfce"
        elif "kde" in desktop:
            return "kde"
        elif "cinnamon" in desktop:
            return "cinnamon"
        elif "mate" in desktop:
            return "mate"
        return "gnome"

    def load_data(self):
        try:
            with open(os.path.join(self.data_dir, "data.json"), "r", encoding="utf-8") as file:
                self.datas = json.loads(file.read())
            with open(os.path.join(self.data_dir, "custom_shortcuts.json"), "r", encoding="utf-8") as file2:
                self.custom_shortcuts = json.loads(file2.read())
            with open(os.path.join(self.data_dir, "shortcuts.json"), "r", encoding="utf-8") as file3:
                self.shortcuts = json.loads(file3.read())
        except Exception as e:
            print(f"Error loading shortcut data: {e}")
            self.datas = {}

    def on_key_pressed(self, controller, keyval, keycode, state):
        if keyval == Gdk.KEY_Escape:
            if hasattr(self, "search_bar") and self.search_bar.get_search_mode():
                self.search_bar.set_search_mode(False)
                return True
            if self.greeter_mode:
                self.close()
                return True
        elif keyval in (Gdk.KEY_f, Gdk.KEY_F) and (state & Gdk.ModifierType.CONTROL_MASK):
            if hasattr(self, "search_bar"):
                self.search_bar.set_search_mode(not self.search_bar.get_search_mode())
                return True
        elif keyval in (Gdk.KEY_p, Gdk.KEY_P) and (state & Gdk.ModifierType.CONTROL_MASK):
            self.export_cheat_sheet(None)
            return True
        return False

    def update_ui(self):
        root_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)

        # HeaderBar
        header = Adw.HeaderBar()
        title_widget = Adw.WindowTitle(
            title=_("Pars Linux Shortcuts"),
            subtitle=_("Greeter Companion") if self.greeter_mode else _("Keyboard Shortcuts Guide")
        )
        header.set_title_widget(title_widget)

        # View Mode Switch Button
        icon_name = "view-list-symbolic" if self.current_mode == "grid" else "view-grid-symbolic"
        tooltip = _("Switch to List View") if self.current_mode == "grid" else _("Switch to Grid View")

        toggle_btn = Gtk.Button(icon_name=icon_name)
        toggle_btn.set_tooltip_text(tooltip)
        toggle_btn.connect("clicked", self.toggle_mode)
        header.pack_start(toggle_btn)

        # Search Toggle Button
        search_btn = Gtk.ToggleButton(icon_name="system-search-symbolic")
        search_btn.set_tooltip_text(_("Search Shortcuts (Ctrl+F)"))
        header.pack_start(search_btn)

        # Export Cheat-Sheet Button
        export_btn = Gtk.Button(icon_name="document-save-symbolic")
        export_btn.set_tooltip_text(_("Export Shortcuts Cheat-Sheet (Ctrl+P)"))
        export_btn.connect("clicked", self.export_cheat_sheet)
        header.pack_start(export_btn)

        # Settings Button (Open Desktop Keyboard Settings)
        settings_btn = Gtk.Button(icon_name="preferences-desktop-keyboard-shortcuts-symbolic")
        settings_btn.set_tooltip_text(_("Open System Keyboard Shortcut Settings"))
        settings_btn.connect("clicked", self.open_system_settings)
        header.pack_start(settings_btn)

        # About Button
        about_btn = Gtk.Button(icon_name="help-about-symbolic")
        about_btn.set_tooltip_text(_("About Pars Linux Shortcuts"))
        about_btn.connect("clicked", self.show_about_dialog)
        header.pack_end(about_btn)

        if self.greeter_mode:
            close_btn = Gtk.Button(label=_("Close"))
            close_btn.add_css_class("suggested-action")
            close_btn.connect("clicked", lambda b: self.close())
            header.pack_end(close_btn)

        root_box.append(header)

        # Search Bar
        self.search_bar = Gtk.SearchBar()
        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_placeholder_text(_("Search shortcuts (e.g. terminal, screenshot, workspace)..."))
        self.search_entry.set_hexpand(True)
        self.search_entry.connect("search-changed", self.on_search_changed)

        search_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        search_box.set_margin_start(16)
        search_box.set_margin_end(16)
        search_box.set_margin_top(8)
        search_box.set_margin_bottom(8)
        search_box.append(self.search_entry)

        self.search_bar.set_child(search_box)
        self.search_bar.connect_entry(self.search_entry)
        search_btn.bind_property("active", self.search_bar, "search-mode-enabled", GObject.BindingFlags.BIDIRECTIONAL)
        root_box.append(self.search_bar)

        # Main Content
        if self.current_mode == "grid":
            content = self.create_grid_view()
        else:
            content = self.create_list_view()

        scrolled = Gtk.ScrolledWindow()
        scrolled.set_vexpand(True)
        scrolled.set_hexpand(True)
        scrolled.set_child(content)
        root_box.append(scrolled)

        self.toast_overlay.set_child(root_box)
        self.set_content(self.toast_overlay)

    def on_search_changed(self, entry):
        self.search_query = entry.get_text().strip().lower()
        self.update_ui()

    def toggle_mode(self, widget):
        self.current_mode = "list" if self.current_mode == "grid" else "grid"
        self.update_ui()

    def open_system_settings(self, widget=None):
        commands = {
            "gnome": ["gnome-control-center", "keyboard"],
            "xfce": ["xfce4-keyboard-settings"],
            "kde": ["kcmshell6", "kcm_keys"],
            "cinnamon": ["cinnamon-settings", "keyboard"],
            "mate": ["mate-keyboard-properties"]
        }

        target_cmds = [commands.get(self.desktop_env, ["gnome-control-center", "keyboard"])]
        # Fallbacks
        target_cmds.extend([
            ["gnome-control-center", "keyboard"],
            ["kcmshell5", "keys"],
            ["xfce4-keyboard-settings"]
        ])

        launched = False
        for cmd in target_cmds:
            if shutil.which(cmd[0]):
                try:
                    subprocess.Popen(cmd)
                    launched = True
                    toast = Adw.Toast.new(_("Opened Keyboard Shortcut Settings"))
                    self.toast_overlay.add_toast(toast)
                    break
                except Exception:
                    pass

        if not launched:
            toast = Adw.Toast.new(_("Could not find a desktop settings application."))
            self.toast_overlay.add_toast(toast)

    def export_cheat_sheet(self, widget=None):
        try:
            home_dir = os.path.expanduser("~")
            desktop_dir = os.path.join(home_dir, "Masaüstü")
            if not os.path.exists(desktop_dir):
                desktop_dir = os.path.join(home_dir, "Desktop")
            if not os.path.exists(desktop_dir):
                desktop_dir = home_dir

            export_file = os.path.join(desktop_dir, "parslinux-shortcuts-cheatsheet.html")

            # Generate beautiful HTML cheat-sheet
            html_content = self.generate_cheatsheet_html()
            with open(export_file, "w", encoding="utf-8") as f:
                f.write(html_content)

            toast = Adw.Toast.new(_(f"Cheat-Sheet saved: {os.path.basename(export_file)}"))
            toast.set_button_label(_("Open"))
            toast.connect("button-clicked", lambda t: subprocess.Popen(["xdg-open", export_file]))
            self.toast_overlay.add_toast(toast)
        except Exception as e:
            toast = Adw.Toast.new(f"Export error: {e}")
            self.toast_overlay.add_toast(toast)

    def generate_cheatsheet_html(self):
        cards_html = ""
        category_icons = {
            "System": "⚙️",
            "Launchers": "🚀",
            "Screenshot Tool": "📸",
            "Workspace": "🖥️"
        }

        for category_name, category_data in self.datas.items():
            schema = category_data.get("schema")
            datas = category_data.get("datas", [])
            icon = category_icons.get(category_name, "📌")

            items_html = ""
            for data in datas:
                key = data["key"]
                name = _(data["name"])
                custom = data.get("custom", False)
                item_schema = data.get("schema", schema)
                values = self.fun_get_keybinding(item_schema, key, custom, raw=True)
                if values:
                    val_badges = " ".join([f"<kbd>{v.replace('<', '').replace('>', ' + ')}</kbd>" for v in values])
                    items_html += f"""
                    <div class="row">
                        <span class="name">{name}</span>
                        <span class="keys">{val_badges}</span>
                    </div>
                    """

            cards_html += f"""
            <div class="card">
                <h2>{icon} {_(category_name)}</h2>
                {items_html}
            </div>
            """

        return f"""<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="utf-8">
<title>Pars Linux Klavye Kısayolları Kılavuzu</title>
<style>
  body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    background: #0f172a;
    color: #f8fafc;
    padding: 30px;
    margin: 0;
  }}
  .header {{
    text-align: center;
    margin-bottom: 30px;
    border-bottom: 2px solid #1e293b;
    padding-bottom: 20px;
  }}
  h1 {{ color: #38bdf8; margin: 0 0 8px 0; font-size: 28px; }}
  p.subtitle {{ color: #94a3b8; margin: 0; font-size: 14px; }}
  .grid {{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    gap: 20px;
    max-width: 1200px;
    margin: 0 auto;
  }}
  .card {{
    background: #1e293b;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 4px 6px -1px rgba(0,0,0,0.3);
    border: 1px solid #334155;
  }}
  .card h2 {{
    color: #7dd3fc;
    font-size: 18px;
    margin-top: 0;
    margin-bottom: 15px;
    padding-bottom: 8px;
    border-bottom: 1px solid #334155;
  }}
  .row {{
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 0;
    border-bottom: 1px solid #2d3748;
  }}
  .row:last-child {{ border-bottom: none; }}
  .name {{ font-size: 14px; color: #e2e8f0; }}
  kbd {{
    background: #0f172a;
    border: 1px solid #475569;
    border-radius: 6px;
    padding: 3px 8px;
    font-size: 12px;
    font-weight: 600;
    color: #38bdf8;
    box-shadow: 0 2px 0 #334155;
    white-space: nowrap;
  }}
  @media print {{
    body {{ background: #fff; color: #000; }}
    .card {{ border: 1px solid #ccc; background: #fafafa; }}
    .card h2 {{ color: #0284c7; border-color: #ddd; }}
    .name {{ color: #111; }}
    kbd {{ background: #eee; border-color: #999; color: #000; box-shadow: none; }}
  }}
</style>
</head>
<body>
  <div class="header">
    <h1>🐆 Pars Linux Klavye Kısayolları Kılavuzu</h1>
    <p class="subtitle">Pars Linux GNOME Masaüstü ve Sistem Kısayolları Hızlı Başvuru Kartı (Cheat-Sheet)</p>
  </div>
  <div class="grid">
    {cards_html}
  </div>
</body>
</html>"""

    def get_app_version(self):
        try:
            version_path = os.path.join(self.script_dir, "../__version__")
            if os.path.exists(version_path):
                with open(version_path, "r", encoding="utf-8") as f:
                    return f.readline().strip()
        except Exception:
            pass
        return "0.1.0"

    def show_about_dialog(self, widget):
        about = Adw.AboutWindow()
        about.set_transient_for(self)
        about.set_application_name(_("Pars Linux Shortcuts"))
        about.set_application_icon("parslinux-shortcuts")
        about.set_developer_name("Pars Linux Team")
        about.set_version(self.get_app_version())
        about.set_copyright("© 2026 Pars Linux Project")
        about.set_website("https://parslinux.org")
        about.set_issue_url("https://github.com/parslinux/parslinux-shortcuts")
        about.set_license_type(Gtk.License.GPL_3_0)
        about.set_comments(_("A modern keyboard shortcut viewer, editor launcher, and cheat-sheet guide integrated with Pars Linux Greeter."))
        about.present()

    def get_filtered_datas(self):
        if not self.search_query:
            return self.datas

        filtered = {}
        for category_name, category_data in self.datas.items():
            schema = category_data.get("schema")
            matched_items = []
            for item in category_data.get("datas", []):
                name = _(item["name"])
                values = self.fun_get_keybinding(item.get("schema", schema), item["key"], item.get("custom", False), raw=True)
                val_str = " ".join(values).lower()
                if self.search_query in name.lower() or self.search_query in val_str or self.search_query in _(category_name).lower():
                    matched_items.append(item)
            if matched_items:
                filtered[category_name] = {
                    "schema": schema,
                    "datas": matched_items
                }
        return filtered

    def create_grid_view(self):
        main_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        main_box.set_margin_top(18)
        main_box.set_margin_bottom(18)
        main_box.set_margin_start(20)
        main_box.set_margin_end(20)
        main_box.set_hexpand(True)

        col1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        col1.set_hexpand(True)
        col1.set_valign(Gtk.Align.START)

        col2 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        col2.set_hexpand(True)
        col2.set_valign(Gtk.Align.START)

        col3 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        col3.set_hexpand(True)
        col3.set_valign(Gtk.Align.START)

        main_box.append(col1)
        main_box.append(col2)
        main_box.append(col3)

        category_icons = {
            "System": "preferences-system-symbolic",
            "Launchers": "system-run-symbolic",
            "Screenshot Tool": "camera-photo-symbolic",
            "Workspace": "view-paged-symbolic"
        }

        datas_to_show = self.get_filtered_datas()

        cards = {}
        for category_name, category_data in datas_to_show.items():
            card_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            card_box.add_css_class("card")
            card_box.set_vexpand(False)

            inner_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            inner_box.set_margin_top(16)
            inner_box.set_margin_bottom(16)
            inner_box.set_margin_start(16)
            inner_box.set_margin_end(16)
            card_box.append(inner_box)

            # Title
            title_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            icon_name = category_icons.get(category_name, "applications-system-symbolic")
            icon = Gtk.Image.new_from_icon_name(icon_name)
            icon.set_pixel_size(20)
            title_box.append(icon)

            title_label = Gtk.Label(label=_(category_name))
            title_label.add_css_class("title-4")
            title_label.set_halign(Gtk.Align.START)
            title_box.append(title_label)
            inner_box.append(title_box)

            title_sep = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
            title_sep.set_margin_top(10)
            title_sep.set_margin_bottom(6)
            inner_box.append(title_sep)

            schema = category_data.get("schema")
            datas = category_data.get("datas", [])

            temp_widgets = []
            for data in datas:
                row_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
                key = data["key"]
                name = data["name"]
                custom = data.get("custom", False)
                item_schema = data.get("schema", schema)

                values = self.fun_get_keybinding(item_schema, key, custom, raw=True)

                if values:
                    name_label = Gtk.Label(label=_(name))
                    name_label.set_halign(Gtk.Align.START)
                    row_box.append(name_label)

                    shortcuts_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
                    shortcuts_box.set_halign(Gtk.Align.START)
                    for val in values:
                        shortcut_label = Gtk.ShortcutLabel(accelerator=val)
                        shortcuts_box.append(shortcut_label)
                    row_box.append(shortcuts_box)
                    temp_widgets.append(row_box)

            for i, widget in enumerate(temp_widgets):
                inner_box.append(widget)
                if i < len(temp_widgets) - 1:
                    sep = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
                    sep.set_margin_top(4)
                    sep.set_margin_bottom(4)
                    inner_box.append(sep)

            cards[category_name] = card_box

        # Placement in columns
        col1_cats = ["System"]
        col2_cats = ["Launchers", "Screenshot Tool"]
        col3_cats = ["Workspace"]

        for cat in col1_cats:
            if cat in cards:
                col1.append(cards[cat])
        for cat in col2_cats:
            if cat in cards:
                col2.append(cards[cat])
        for cat in col3_cats:
            if cat in cards:
                col3.append(cards[cat])

        known_cats = col1_cats + col2_cats + col3_cats
        for cat, card in cards.items():
            if cat not in known_cats:
                col3.append(card)

        if not cards:
            status_page = Adw.StatusPage()
            status_page.set_icon_name("system-search-symbolic")
            status_page.set_title(_("No Shortcuts Found"))
            status_page.set_description(_("Try a different search term or clear the filter."))
            return status_page

        return main_box

    def create_list_view(self):
        pref_page = Adw.PreferencesPage()
        pref_page.set_margin_top(12)
        pref_page.set_margin_bottom(12)

        datas_to_show = self.get_filtered_datas()

        if not datas_to_show:
            status_page = Adw.StatusPage()
            status_page.set_icon_name("system-search-symbolic")
            status_page.set_title(_("No Shortcuts Found"))
            status_page.set_description(_("Try a different search term or clear the filter."))
            return status_page

        for category_name, category_data in datas_to_show.items():
            group = Adw.PreferencesGroup()
            group.set_title(_(category_name))
            pref_page.add(group)

            schema = category_data.get("schema")
            datas = category_data.get("datas", [])

            for data in datas:
                key = data["key"]
                name = data["name"]
                custom = data.get("custom", False)
                item_schema = data.get("schema", schema)

                values = self.fun_get_keybinding(item_schema, key, custom, raw=True)

                if values:
                    for val in values:
                        row = Adw.ActionRow()
                        row.set_title(_(name))
                        row.set_activatable(True)
                        row.connect("activated", lambda r: self.open_system_settings())
                        shortcut_label = Gtk.ShortcutLabel(accelerator=val)
                        shortcut_label.set_halign(Gtk.Align.END)
                        shortcut_label.set_valign(Gtk.Align.CENTER)
                        row.add_suffix(shortcut_label)
                        group.add(row)

        return pref_page

    def fun_get_keybinding(self, schema, key, is_custom, raw=False):
        binding = []
        if is_custom:
            res = self.fun_get_custom_keybinding(key)
            if res and res.startswith("'") and res.endswith("'"):
                res = res[1:-1]
            if res:
                binding = [res]
            else:
                for item in self.custom_shortcuts:
                    if item.get("id") == key or (key.startswith("parslinux-") and item.get("id") == key.replace("parslinux-", "pardus-")):
                        if item.get("binding"):
                            binding = [item["binding"]]
                            break
        else:
            try:
                settings = Gio.Settings.new(schema)
                binding = settings.get_strv(key)
            except Exception:
                binding = []

            if not binding:
                for item in self.shortcuts:
                    if item.get("schema") == schema and item.get("key") == key:
                        binding = [item.get("binding")]
                        break

        # Filter empty
        binding = [b for b in binding if b]

        if raw:
            return binding

        result = []
        for item in binding:
            temp_parts = item.replace("><", "|").replace("<", "").replace(">", "|").split("|")
            temp_parts = [p for p in temp_parts if p]
            result.append(temp_parts)

        return result

    def fun_get_custom_keybinding(self, key):
        keys_to_try = [key]
        if key.startswith("parslinux-"):
            keys_to_try.append(key.replace("parslinux-", "pardus-"))

        for k in keys_to_try:
            dconf_path = "dconf read /org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/{key}/binding".format(key=k)
            try:
                val = subprocess.getoutput(dconf_path).strip()
                if val:
                    return val
            except Exception:
                pass
        return ""
